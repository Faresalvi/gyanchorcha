from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('quiz', '0002_teammember'),
    ]

    operations = [
        migrations.CreateModel(
            name='AboutPage',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('heading', models.CharField(blank=True, max_length=160)),
                ('heading_bn', models.CharField(blank=True, max_length=160, verbose_name='heading (Bangla)')),
                ('intro', models.TextField(blank=True, verbose_name='short intro')),
                ('intro_bn', models.TextField(blank=True, verbose_name='short intro (Bangla)')),
                ('story', models.TextField(blank=True, verbose_name='our story / mission')),
                ('story_bn', models.TextField(blank=True, verbose_name='our story / mission (Bangla)')),
                ('contact_email', models.EmailField(blank=True, max_length=254, verbose_name='contact email')),
            ],
        ),
    ]
