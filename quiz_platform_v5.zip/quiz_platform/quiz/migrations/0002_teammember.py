from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('quiz', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='TeamMember',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=120)),
                ('name_bn', models.CharField(blank=True, max_length=120, verbose_name='name (Bangla)')),
                ('role', models.CharField(max_length=120)),
                ('role_bn', models.CharField(blank=True, max_length=120, verbose_name='role (Bangla)')),
                ('bio', models.TextField(blank=True, verbose_name='work / about')),
                ('bio_bn', models.TextField(blank=True, verbose_name='work / about (Bangla)')),
                ('photo_url', models.URLField(blank=True, max_length=500, verbose_name='photo link (optional)')),
                ('order', models.PositiveSmallIntegerField(default=0, verbose_name='order (small number comes first)')),
                ('is_active', models.BooleanField(default=True)),
            ],
            options={
                'ordering': ['order', 'id'],
            },
        ),
    ]
