from django.core.management.base import BaseCommand

from quiz.models import Category, Question, Quiz, User

from .seed_data import CATEGORIES

class Command(BaseCommand):
    help = 'Create demo categories, questions, quizzes and a demo admin/student account.'

    def handle(self, *args, **options):
        created_q = 0
        categories = {}
        for name, name_bn, rows in CATEGORIES:
            cat, _ = Category.objects.get_or_create(name=name, defaults={'name_bn': name_bn})
            categories[name] = cat
            for q, a, b, c, d, right in rows:
                # Bangla-first: the text is saved in both fields so it shows in either language.
                _, made = Question.objects.get_or_create(
                    question_text=q, category=cat,
                    defaults=dict(question_text_bn=q, option_a=a, option_b=b, option_c=c,
                                  option_d=d, correct_option=right))
                created_q += made

        quizzes = [
            ('Quick Mix Quiz', 'দ্রুত মিশ্র কুইজ', 'A mix of questions from every category.',
             'সব বিভাগ থেকে মিশ্র প্রশ্ন।', []),
            ('General Knowledge Quiz', 'সাধারণ জ্ঞান কুইজ', 'Test your general knowledge.',
             'আপনার সাধারণ জ্ঞান যাচাই করুন।', ['General Knowledge']),
            ('Science Quiz', 'বিজ্ঞান কুইজ', 'Basic science questions.', 'বিজ্ঞানের মৌলিক প্রশ্ন।', ['Science']),
            ('Bangladesh Quiz', 'বাংলাদেশ কুইজ', 'How well do you know Bangladesh?',
             'বাংলাদেশ সম্পর্কে আপনি কতটা জানেন?', ['Bangladesh']),
        ]
        for title, title_bn, desc, desc_bn, cats in quizzes:
            quiz, created = Quiz.objects.get_or_create(
                title=title, defaults=dict(title_bn=title_bn, description=desc, description_bn=desc_bn,
                                           is_published=True))
            if created:
                quiz.categories.set([categories[c] for c in cats])

        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@quiz.local', 'Admin@12345', first_name='Admin')
            self.stdout.write('Admin created -> email: admin@quiz.local  password: Admin@12345')
        if not User.objects.filter(username='student1').exists():
            User.objects.create_user('student1', 'student1@quiz.local', 'Student@12345',
                                     first_name='Demo Student')
            self.stdout.write('Student created -> email: student1@quiz.local  password: Student@12345')
        self.stdout.write(self.style.SUCCESS(f'Demo data ready ({created_q} new questions). '
                                             'Please change the demo passwords before going live.'))
