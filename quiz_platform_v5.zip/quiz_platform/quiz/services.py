"""Business logic: random questions, scoring, leaderboard and Excel import."""
import random
from decimal import Decimal
from io import BytesIO

from django.db import transaction
from django.utils import timezone

from .models import Attempt, AttemptAnswer, Category, Question


class NotEnoughQuestions(Exception):
    pass


# ---------------------------------------------------------------- questions
def eligible_questions(quiz=None, category_ids=None):
    """Active questions (in active categories) that this quiz may use."""
    qs = Question.objects.filter(is_active=True, category__is_active=True)
    if category_ids is None and quiz is not None and quiz.pk:
        category_ids = list(quiz.categories.values_list('pk', flat=True))
    if category_ids:
        qs = qs.filter(category_id__in=category_ids)
    return qs


def start_attempt(quiz, student=None, guest_name=''):
    ids = list(eligible_questions(quiz).values_list('id', flat=True))
    if len(ids) < quiz.question_count:
        raise NotEnoughQuestions(len(ids))
    # random.sample never repeats an item, so a question can't appear twice.
    chosen = random.sample(ids, quiz.question_count)
    with transaction.atomic():
        attempt = Attempt.objects.create(
            quiz=quiz, student=student, guest_name=guest_name,
            total_questions=len(chosen),
            seconds_per_question=quiz.seconds_per_question,
            correct_mark=quiz.correct_mark, negative_mark=quiz.negative_mark,
        )
        AttemptAnswer.objects.bulk_create([
            AttemptAnswer(attempt=attempt, question_id=qid, position=i)
            for i, qid in enumerate(chosen)
        ])
    return attempt


# ----------------------------------------------------------------- scoring
def calculate_score(correct, wrong, correct_mark, negative_mark):
    return Decimal(correct) * Decimal(correct_mark) - Decimal(wrong) * Decimal(negative_mark)


def finalize_attempt(attempt):
    """Mark answers, count results and close the attempt. Safe to call twice."""
    with transaction.atomic():
        attempt = Attempt.objects.select_related('quiz').get(pk=attempt.pk)
        if attempt.status == Attempt.Status.SUBMITTED:
            return attempt
        answers = list(attempt.answers.select_related('question'))
        correct = wrong = unanswered = 0
        last_answer_time = None
        for a in answers:
            if not a.selected_option:
                a.is_correct = None
                unanswered += 1
                continue
            a.is_correct = a.selected_option == a.question.correct_option
            if a.is_correct:
                correct += 1
            else:
                wrong += 1
            if a.answered_at and (last_answer_time is None or a.answered_at > last_answer_time):
                last_answer_time = a.answered_at
        AttemptAnswer.objects.bulk_update(answers, ['is_correct'])

        now = timezone.now()
        end = min(now, attempt.deadline)
        if last_answer_time:
            taken = (min(last_answer_time, attempt.deadline) - attempt.started_at).total_seconds()
        else:
            taken = attempt.total_seconds
        attempt.correct_count = correct
        attempt.wrong_count = wrong
        attempt.unanswered_count = unanswered
        attempt.score = calculate_score(correct, wrong, attempt.correct_mark, attempt.negative_mark)
        attempt.time_taken_seconds = max(0, int(taken))
        attempt.submitted_at = end
        attempt.status = Attempt.Status.SUBMITTED
        attempt.save()
    return attempt


def finalize_expired():
    """Close every attempt whose time is over (nobody opened it again)."""
    now = timezone.now()
    for attempt in Attempt.objects.filter(status=Attempt.Status.IN_PROGRESS):
        if attempt.is_expired(now):
            finalize_attempt(attempt)


# ------------------------------------------------------------- leaderboard
def build_leaderboard(quiz=None, limit=None):
    """Rank by score, then correct answers, then less time taken.

    Every student appears once (their best attempt). Each guest attempt is its own row.
    """
    finalize_expired()
    qs = Attempt.objects.filter(status=Attempt.Status.SUBMITTED).select_related('student', 'quiz')
    if quiz is not None:
        qs = qs.filter(quiz=quiz)
    qs = qs.order_by('-score', '-correct_count', 'time_taken_seconds', 'submitted_at')
    seen, rows = set(), []
    for attempt in qs:
        if attempt.student_id:
            if attempt.student_id in seen:
                continue
            seen.add(attempt.student_id)
        rows.append(attempt)
    previous, rank = None, 0
    for position, attempt in enumerate(rows, start=1):
        key = (attempt.score, attempt.correct_count, attempt.time_taken_seconds)
        if key != previous:
            rank, previous = position, key
        attempt.rank = rank
    return rows[:limit] if limit else rows


def rank_of_student(user, quiz=None):
    for row in build_leaderboard(quiz):
        if row.student_id == user.id:
            return row.rank
    return None


# ------------------------------------------------------------- Excel import
EXCEL_HEADERS = ['Question', 'Option A', 'Option B', 'Option C', 'Option D',
                 'Correct Answer', 'Category', 'Explanation', 'Question (Bangla)', 'Category (Bangla)']
MAX_IMPORT_ROWS = 2000


def build_excel_template():
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = 'Questions'
    ws.append(EXCEL_HEADERS)
    ws.append(['What is the capital of Bangladesh?', 'Chattogram', 'Dhaka', 'Sylhet', 'Khulna',
               'B', 'General Knowledge', 'Dhaka is the capital and largest city.',
               'বাংলাদেশের রাজধানী কী?', 'সাধারণ জ্ঞান'])
    ws.append(['Which gas do plants absorb from the air?', 'Oxygen', 'Nitrogen', 'Carbon dioxide',
               'Hydrogen', 'C', 'Science', 'Plants use CO2 for photosynthesis.',
               'উদ্ভিদ বাতাস থেকে কোন গ্যাস গ্রহণ করে?', 'বিজ্ঞান'])
    for cell in ws[1]:
        cell.font = Font(bold=True, color='FFFFFF')
        cell.fill = PatternFill('solid', fgColor='006A4E')
        cell.alignment = Alignment(horizontal='center')
    for col, width in zip('ABCDEFGHIJ', [48, 22, 22, 22, 22, 16, 22, 44, 48, 22]):
        ws.column_dimensions[col].width = width
    ws.freeze_panes = 'A2'
    out = BytesIO()
    wb.save(out)
    return out.getvalue()


def _cell(value):
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def parse_excel(file):
    """Read an .xlsx file. Returns (valid_rows, errors, total_rows_read)."""
    from openpyxl import load_workbook

    wb = load_workbook(file, read_only=True, data_only=True)
    ws = wb.active
    valid, errors, total = [], [], 0
    for number, row in enumerate(ws.iter_rows(values_only=True), start=1):
        cells = [_cell(v) for v in (list(row) + [None] * 10)[:10]]
        if not any(cells):
            continue
        if number == 1 and cells[0].lower() == 'question':
            continue  # header row
        total += 1
        if total > MAX_IMPORT_ROWS:
            errors.append({'row': number, 'message': f'Too many rows (limit {MAX_IMPORT_ROWS}).'})
            break
        question, a, b, c, d, correct, category, explanation, question_bn, category_bn = cells
        problems = []
        if not question:
            problems.append('Question is empty')
        for letter, text in zip('ABCD', (a, b, c, d)):
            if not text:
                problems.append(f'Option {letter} is empty')
        answer = correct.upper().replace('OPTION', '').strip()
        answer = {'1': 'A', '2': 'B', '3': 'C', '4': 'D'}.get(answer, answer)
        if answer not in ('A', 'B', 'C', 'D'):
            problems.append('Correct Answer must be A, B, C or D')
        if not category:
            problems.append('Category is empty')
        if problems:
            errors.append({'row': number, 'message': '; '.join(problems)})
            continue
        valid.append({'question': question, 'a': a, 'b': b, 'c': c, 'd': d,
                      'correct': answer, 'category': category, 'explanation': explanation,
                      'question_bn': question_bn, 'category_bn': category_bn})
    wb.close()
    return valid, errors, total


@transaction.atomic
def import_questions(rows):
    """Insert validated rows. Missing categories are created automatically."""
    categories = {c.name.lower(): c for c in Category.objects.all()}
    new_categories = 0
    objects = []
    for r in rows:
        key = r['category'].lower()
        if key not in categories:
            categories[key] = Category.objects.create(name=r['category'][:120],
                                                      name_bn=r.get('category_bn', '')[:120])
            new_categories += 1
        objects.append(Question(
            category=categories[key], question_text=r['question'],
            question_text_bn=r.get('question_bn', ''),
            option_a=r['a'], option_b=r['b'], option_c=r['c'], option_d=r['d'],
            correct_option=r['correct'], explanation=r['explanation'],
        ))
    Question.objects.bulk_create(objects)
    return len(objects), new_categories
