"""Public pages: welcome, quizzes, quiz play, result, leaderboard, login, dashboard."""
import math

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.db.models import Count, Q, Sum
from django.http import Http404, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from .decorators import student_required
from .forms import GuestNameForm, LoginForm, RegisterForm
from .i18n import t
from .models import AboutPage, Attempt, AttemptAnswer, Category, Question, Quiz, TeamMember, User
from .services import (NotEnoughQuestions, build_leaderboard, eligible_questions,
                       finalize_attempt, rank_of_student, start_attempt)

BACKEND = 'quiz.backends.EmailBackend'


# ---------------------------------------------------------------- helpers
def _safe_next(request, default):
    target = request.POST.get('next') or request.GET.get('next') or ''
    if target and url_has_allowed_host_and_scheme(target, allowed_hosts={request.get_host()}):
        return target
    return default


def _guest_ids(request):
    return request.session.get('guest_attempts', [])


def _claim_guest_attempts(request, user):
    """Attach the guest quiz attempts of this browser to the account."""
    ids = _guest_ids(request)
    count = 0
    if ids:
        count = Attempt.objects.filter(pk__in=ids, student__isnull=True).update(
            student=user, guest_name='')
        request.session['guest_attempts'] = []
    return count


def _get_attempt(request, attempt_id, allow_admin=False):
    attempt = get_object_or_404(Attempt.objects.select_related('quiz', 'student'), pk=attempt_id)
    user = request.user
    if user.is_authenticated:
        if attempt.student_id == user.id:
            return attempt
        if allow_admin and user.is_platform_admin():
            return attempt
    if attempt.student_id is None and attempt.pk in _guest_ids(request):
        return attempt
    raise Http404


# ------------------------------------------------------------ switch language
def set_language(request, code):
    if code in ('bn', 'en'):
        request.session['lang'] = code
    return HttpResponseRedirect(_safe_next(request, '/'))


# ------------------------------------------------------------------ welcome
def home(request):
    context = {
        'quiz_count': Quiz.objects.filter(is_published=True).count(),
        'question_count': Question.objects.filter(is_active=True).count(),
    }
    return render(request, 'quiz/home.html', context)


# ------------------------------------------------------------------ quizzes
def quiz_list(request):
    categories = Category.objects.filter(is_active=True)
    selected = None
    quizzes = Quiz.objects.filter(is_published=True).prefetch_related('categories')
    cat_id = request.GET.get('category', '')
    if cat_id.isdigit():
        selected = categories.filter(pk=int(cat_id)).first()
    if selected:
        quizzes = quizzes.filter(Q(categories=selected) | Q(categories__isnull=True)).distinct()
    items = []
    for quiz in quizzes:
        ready = eligible_questions(quiz).count() >= quiz.question_count
        items.append({'quiz': quiz, 'ready': ready})
    return render(request, 'quiz/quiz_list.html', {
        'categories': categories, 'selected': selected, 'items': items})


def quiz_detail(request, quiz_id):
    quiz = get_object_or_404(Quiz.objects.prefetch_related('categories'), pk=quiz_id, is_published=True)
    ready = eligible_questions(quiz).count() >= quiz.question_count
    blocked = False
    if not quiz.allow_retake:
        blocked = _previous_attempts(request, quiz).exists()
    form = GuestNameForm(initial={'name': request.session.get('guest_name', '')})
    return render(request, 'quiz/quiz_detail.html', {
        'quiz': quiz, 'ready': ready, 'blocked': blocked, 'form': form})


def _previous_attempts(request, quiz):
    if request.user.is_authenticated:
        return Attempt.objects.filter(quiz=quiz, student=request.user)
    return Attempt.objects.filter(quiz=quiz, pk__in=_guest_ids(request))


@require_POST
def quiz_start(request, quiz_id):
    quiz = get_object_or_404(Quiz, pk=quiz_id, is_published=True)
    user = request.user
    if user.is_authenticated and user.is_platform_admin():
        messages.error(request, t(request, 'Admins cannot take quizzes. Please use a student or guest session.'))
        return redirect('quiz_detail', quiz_id=quiz.pk)

    # Continue an unfinished attempt instead of starting a second one.
    for attempt in _previous_attempts(request, quiz).filter(status=Attempt.Status.IN_PROGRESS):
        if not attempt.is_expired():
            return redirect('play', attempt_id=attempt.pk)
        finalize_attempt(attempt)

    if not quiz.allow_retake and _previous_attempts(request, quiz).exists():
        messages.error(request, t(request, 'Retake is not allowed for this quiz.'))
        return redirect('quiz_detail', quiz_id=quiz.pk)

    guest_name = ''
    if not user.is_authenticated:
        form = GuestNameForm(request.POST)
        if not form.is_valid():
            messages.error(request, t(request, 'Please enter your name to start as a guest.'))
            return redirect('quiz_detail', quiz_id=quiz.pk)
        guest_name = form.cleaned_data['name'].strip()
        request.session['guest_name'] = guest_name

    try:
        attempt = start_attempt(quiz, student=user if user.is_authenticated else None,
                                guest_name=guest_name)
    except NotEnoughQuestions:
        messages.error(request, t(request, 'This quiz cannot start yet because there are not enough questions.'))
        return redirect('quiz_detail', quiz_id=quiz.pk)

    if not user.is_authenticated:
        request.session['guest_attempts'] = _guest_ids(request) + [attempt.pk]
    return redirect('play', attempt_id=attempt.pk)


# --------------------------------------------------------------------- play
def _play_url(attempt, number=None):
    url = reverse('play', args=[attempt.pk])
    return f'{url}?q={number}' if number else url


def play(request, attempt_id):
    """One question at a time, with free movement between questions.

    The whole quiz has ONE shared timer: questions x seconds per question
    (10 questions x 30 seconds = 5 minutes). A student who answers fast keeps the
    saved time for harder questions. Answer = jump to the next question.
    The student can go back/forward, change answers, or press "Submit" to finish early.
    When the shared time ends, the server closes the attempt by itself.
    """
    attempt = _get_attempt(request, attempt_id)
    if attempt.status == Attempt.Status.SUBMITTED:
        return redirect('result', attempt_id=attempt.pk)

    now = timezone.now()
    elapsed = (now - attempt.started_at).total_seconds()
    if elapsed >= attempt.total_seconds:
        finalize_attempt(attempt)
        return HttpResponseRedirect(reverse('result', args=[attempt.pk]) + '#join')

    answers = list(attempt.answers.select_related('question').order_by('position'))
    total = len(answers)

    if request.method == 'POST':
        if request.POST.get('action') == 'finish':
            finalize_attempt(attempt)
            return HttpResponseRedirect(reverse('result', args=[attempt.pk]) + '#join')
        try:
            posted = int(request.POST.get('position', '-1'))
        except ValueError:
            posted = -1
        choice = request.POST.get('choice', '')
        if 0 <= posted < total and choice in ('A', 'B', 'C', 'D'):
            answers[posted].selected_option = choice
            answers[posted].answered_at = now
            answers[posted].save(update_fields=['selected_option', 'answered_at'])
            # Answered -> go to the next question straight away (stay on the last one).
            return redirect(_play_url(attempt, min(posted + 2, total)))
        messages.error(request, t(request, 'Please choose one of the options.'))
        return redirect(_play_url(attempt, posted + 1 if 0 <= posted < total else None))

    # Which question to show? ?q=3 -> question 3. Without it: first unanswered one.
    q = request.GET.get('q', '')
    if q.isdigit() and 1 <= int(q) <= total:
        index = int(q) - 1
    else:
        index = next((i for i, a in enumerate(answers) if not a.selected_option), total - 1)

    current = answers[index]
    question = current.question
    options = [{'letter': letter, 'text': text, 'selected': current.selected_option == letter}
               for letter, text in question.options()]
    remaining = max(1, math.ceil(attempt.total_seconds - elapsed))
    answered = sum(1 for a in answers if a.selected_option)
    return render(request, 'quiz/play.html', {
        'attempt': attempt, 'quiz': attempt.quiz, 'question': question, 'options': options,
        'position': index, 'number': index + 1, 'total': total,
        'remaining': remaining, 'total_seconds': attempt.total_seconds,
        'bar_percent': f'{remaining / attempt.total_seconds * 100:.2f}',
        'prev_url': _play_url(attempt, index) if index > 0 else '',
        'next_url': _play_url(attempt, index + 2) if index < total - 1 else '',
        'is_last': index == total - 1,
        'selected': current.selected_option,
        'answered': answered, 'unanswered': total - answered,
        'dots': [{'n': i + 1, 'now': i == index, 'answered': bool(a.selected_option),
                  'url': _play_url(attempt, i + 1)} for i, a in enumerate(answers)],
    })


# ------------------------------------------------------------------- about
def about(request):
    return render(request, 'quiz/about.html', {
        'about': AboutPage.load(),
        'members': TeamMember.objects.filter(is_active=True)})


# ------------------------------------------------------------------- result
def result(request, attempt_id):
    attempt = _get_attempt(request, attempt_id, allow_admin=True)
    if attempt.status != Attempt.Status.SUBMITTED:
        if attempt.is_expired():
            attempt = finalize_attempt(attempt)
        else:
            return redirect('play', attempt_id=attempt.pk)
    answers = attempt.answers.select_related('question__category').order_by('position')
    guest_total = Attempt.objects.filter(pk__in=_guest_ids(request)).count() if attempt.is_guest else 0
    return render(request, 'quiz/result.html', {
        'attempt': attempt, 'answers': answers, 'guest_total': guest_total})


# -------------------------------------------------------------- leaderboard
def leaderboard(request):
    quizzes = Quiz.objects.filter(is_published=True)
    quiz = None
    quiz_id = request.GET.get('quiz', '')
    if quiz_id.isdigit():
        quiz = quizzes.filter(pk=int(quiz_id)).first()
    rows = build_leaderboard(quiz, limit=100)
    return render(request, 'quiz/leaderboard.html', {'rows': rows, 'quizzes': quizzes, 'quiz': quiz})


# ------------------------------------------------------------- auth (student)
def register(request):
    if request.user.is_authenticated:
        return redirect('dashboard' if not request.user.is_platform_admin() else 'panel_dashboard')
    form = RegisterForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        claimed = _claim_guest_attempts(request, user)
        login(request, user, backend=BACKEND)
        messages.success(request, t(request, 'Your account is ready. Welcome!'))
        if claimed:
            messages.success(request, t(request, 'Your guest quiz attempts were added to your account.'))
        return redirect(_safe_next(request, 'dashboard'))
    return render(request, 'auth/register.html', {'form': form, 'next': request.GET.get('next', '')})


def student_login(request):
    if request.user.is_authenticated:
        return redirect('dashboard' if not request.user.is_platform_admin() else 'panel_dashboard')
    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(request, username=form.cleaned_data['email'],
                            password=form.cleaned_data['password'])
        if user is None:
            form.add_error(None, t(request, 'Wrong email or password, or the account is disabled.'))
        elif user.is_platform_admin():
            form.add_error(None, t(request, 'This is an admin account. Please use the Admin Login page.'))
        else:
            claimed = _claim_guest_attempts(request, user)
            login(request, user, backend=BACKEND)
            if claimed:
                messages.success(request, t(request, 'Your guest quiz attempts were added to your account.'))
            return redirect(_safe_next(request, 'dashboard'))
    return render(request, 'auth/login.html', {'form': form, 'next': request.GET.get('next', '')})


@require_POST
def logout_view(request):
    lang = request.session.get('lang')
    logout(request)
    if lang:
        request.session['lang'] = lang
    return redirect('home')


# --------------------------------------------------------- student dashboard
@student_required
def dashboard(request):
    from .services import finalize_expired
    finalize_expired()
    user = request.user
    attempts = Attempt.objects.filter(student=user, status=Attempt.Status.SUBMITTED).select_related('quiz')
    totals = attempts.aggregate(
        correct=Sum('correct_count'), wrong=Sum('wrong_count'), unanswered=Sum('unanswered_count'))
    best = attempts.order_by('-score').first()
    quizzes = Quiz.objects.filter(is_published=True)
    return render(request, 'quiz/dashboard.html', {
        'attempts': attempts[:50], 'attempt_count': attempts.count(),
        'totals': {k: v or 0 for k, v in totals.items()},
        'best': best, 'rank': rank_of_student(user),
        'quizzes': quizzes, 'top': build_leaderboard(limit=5),
    })
