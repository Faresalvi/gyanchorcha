from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import AboutPage, Category, Question, Quiz, TeamMember, User
from .services import eligible_questions


def _style(form):
    for name, field in form.fields.items():
        w = field.widget
        if isinstance(w, (forms.CheckboxInput, forms.CheckboxSelectMultiple)):
            continue
        w.attrs.setdefault('class', 'input')
        if isinstance(w, forms.Textarea):
            w.attrs.setdefault('rows', 3)


class StyledMixin:
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _style(self)


class RegisterForm(StyledMixin, UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'first_name', 'email')
        labels = {'first_name': 'Full name', 'email': 'Email', 'username': 'Username'}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['first_name'].required = True
        self.fields['email'].required = True
        self.fields['password1'].label = 'Password'
        self.fields['password2'].label = 'Confirm password'
        self.fields['username'].help_text = ''
        self.fields['password1'].help_text = ''
        self.fields['password2'].help_text = ''
        for name in ('username', 'first_name', 'email', 'password1', 'password2'):
            self.fields[name].widget.attrs['class'] = 'input'

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError('This email is already registered.')
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = User.Role.STUDENT
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class LoginForm(StyledMixin, forms.Form):
    email = forms.CharField(label='Email', max_length=254)
    password = forms.CharField(label='Password', widget=forms.PasswordInput)


class GuestNameForm(StyledMixin, forms.Form):
    name = forms.CharField(label='Your name', max_length=100)


class CategoryForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Category
        fields = ('name', 'name_bn', 'is_active')
        labels = {'name': 'Category name', 'name_bn': 'Category name (Bangla)', 'is_active': 'Active'}


class QuestionForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Question
        fields = ('category', 'question_text', 'question_text_bn', 'option_a', 'option_b',
                  'option_c', 'option_d', 'correct_option', 'explanation', 'is_active')
        labels = {
            'question_text': 'Question text', 'question_text_bn': 'Question text (Bangla)',
            'option_a': 'Option A', 'option_b': 'Option B', 'option_c': 'Option C',
            'option_d': 'Option D', 'correct_option': 'Correct answer',
            'explanation': 'Explanation (optional)', 'is_active': 'Active',
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].queryset = Category.objects.filter(is_active=True) | Category.objects.filter(
            pk=getattr(self.instance, 'category_id', None))


class QuizForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = Quiz
        fields = ('title', 'title_bn', 'description', 'description_bn', 'categories',
                  'question_count', 'seconds_per_question', 'correct_mark', 'negative_mark',
                  'allow_retake', 'is_published')
        labels = {
            'title': 'Quiz name', 'title_bn': 'Quiz name (Bangla)',
            'description': 'Quiz description', 'description_bn': 'Quiz description (Bangla)',
            'categories': 'Categories (leave empty to use all categories)',
            'question_count': 'Total questions', 'seconds_per_question': 'Seconds per question',
            'correct_mark': 'Marks for a correct answer', 'negative_mark': 'Marks lost for a wrong answer',
            'allow_retake': 'Allow retake', 'is_published': 'Published (visible to students)',
        }
        widgets = {'categories': forms.CheckboxSelectMultiple}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['categories'].queryset = Category.objects.filter(is_active=True)

    def clean(self):
        data = super().clean()
        count = data.get('question_count')
        if data.get('is_published') and count:
            ids = [c.pk for c in data.get('categories', [])]
            if eligible_questions(None, ids).count() < count:
                raise forms.ValidationError(
                    'Not enough active questions for this quiz. Add more questions or lower the total.')
        return data


class StudentEditForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'username', 'email', 'is_active')
        labels = {'first_name': 'Full name', 'username': 'Username', 'email': 'Email',
                  'is_active': 'Account active'}

    def clean_email(self):
        email = self.cleaned_data['email'].strip().lower()
        if User.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
            raise forms.ValidationError('This email is already registered.')
        return email


class ExcelUploadForm(StyledMixin, forms.Form):
    file = forms.FileField(label='Excel file (.xlsx)')

    def clean_file(self):
        f = self.cleaned_data['file']
        if not f.name.lower().endswith('.xlsx'):
            raise forms.ValidationError('Please upload an .xlsx file.')
        if f.size > 5 * 1024 * 1024:
            raise forms.ValidationError('File is too large (maximum 5 MB).')
        return f


class TeamMemberForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = TeamMember
        fields = ('name', 'name_bn', 'role', 'role_bn', 'bio', 'bio_bn', 'photo_url', 'order', 'is_active')
        labels = {
            'name': 'Name', 'name_bn': 'Name (Bangla)', 'role': 'Role', 'role_bn': 'Role (Bangla)',
            'bio': 'Work / about', 'bio_bn': 'Work / about (Bangla)', 'photo_url': 'Photo link (optional)',
            'order': 'Order (small number comes first)', 'is_active': 'Show on About page',
        }


class StudentCreateForm(RegisterForm):
    """Admin adds a student by hand: same fields as sign-up, no captcha-style extras."""


class AboutPageForm(StyledMixin, forms.ModelForm):
    class Meta:
        model = AboutPage
        fields = ('heading', 'heading_bn', 'intro', 'intro_bn', 'story', 'story_bn', 'contact_email')
        labels = {
            'heading': 'Heading', 'heading_bn': 'Heading (Bangla)',
            'intro': 'Short intro', 'intro_bn': 'Short intro (Bangla)',
            'story': 'Our story / mission', 'story_bn': 'Our story / mission (Bangla)',
            'contact_email': 'Contact email (optional)',
        }
        widgets = {'story': forms.Textarea(attrs={'rows': 6}), 'story_bn': forms.Textarea(attrs={'rows': 6})}
