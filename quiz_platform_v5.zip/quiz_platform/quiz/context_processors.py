from django.conf import settings


def site(request):
    lang = request.session.get('lang') or getattr(settings, 'DEFAULT_SITE_LANGUAGE', 'bn')
    return {'lang': lang, 'is_bn': lang == 'bn'}
