from datetime import timedelta
from decimal import Decimal

from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone


class User(AbstractUser):
    """Student or Admin account. Students log in with their e-mail address."""

    class Role(models.TextChoices):
        ADMIN = 'ADMIN', 'Admin'
        STUDENT = 'STUDENT', 'Student'

    email = models.EmailField('email address', unique=True)
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.STUDENT)

    def save(self, *args, **kwargs):
        # A superuser (made with "createsuperuser") is always a platform admin.
        if self.is_superuser:
            self.role = self.Role.ADMIN
        if self.email:
            self.email = self.email.strip().lower()
        super().save(*args, **kwargs)

    def is_platform_admin(self):
        return self.is_superuser or self.role == self.Role.ADMIN

    @property
    def display_name(self):
        return self.first_name.strip() or self.username


class Category(models.Model):
    name = models.CharField(max_length=120, unique=True)
    name_bn = models.CharField('name (Bangla)', max_length=120, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name


class Question(models.Model):
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='questions')
    question_text = models.TextField()
    question_text_bn = models.TextField('question text (Bangla)', blank=True)
    option_a = models.CharField(max_length=500)
    option_b = models.CharField(max_length=500)
    option_c = models.CharField(max_length=500)
    option_d = models.CharField(max_length=500)
    correct_option = models.CharField(
        max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')]
    )
    explanation = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-id']

    def __str__(self):
        return self.question_text[:80]

    def options(self):
        return [('A', self.option_a), ('B', self.option_b),
                ('C', self.option_c), ('D', self.option_d)]

    def option_text(self, letter):
        return dict(self.options()).get(letter, '')


class Quiz(models.Model):
    title = models.CharField(max_length=180)
    title_bn = models.CharField('title (Bangla)', max_length=180, blank=True)
    description = models.TextField(blank=True)
    description_bn = models.TextField('description (Bangla)', blank=True)
    categories = models.ManyToManyField(Category, related_name='quizzes', blank=True)
    question_count = models.PositiveSmallIntegerField(default=10, validators=[MinValueValidator(1)])
    seconds_per_question = models.PositiveSmallIntegerField(default=30, validators=[MinValueValidator(5)])
    correct_mark = models.DecimalField(max_digits=4, decimal_places=2, default=Decimal('1.00'))
    negative_mark = models.DecimalField(max_digits=4, decimal_places=2, default=Decimal('0.50'))
    allow_retake = models.BooleanField(default=True)
    is_published = models.BooleanField(default=False)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='created_quizzes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-id']
        verbose_name_plural = 'Quizzes'

    def __str__(self):
        return self.title

    @property
    def total_seconds(self):
        return self.question_count * self.seconds_per_question

    @property
    def total_minutes(self):
        minutes = self.total_seconds / 60
        return int(minutes) if minutes == int(minutes) else round(minutes, 1)


class Attempt(models.Model):
    class Status(models.TextChoices):
        IN_PROGRESS = 'IN_PROGRESS', 'In progress'
        SUBMITTED = 'SUBMITTED', 'Submitted'

    quiz = models.ForeignKey(Quiz, on_delete=models.PROTECT, related_name='attempts')
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='quiz_attempts',
                                null=True, blank=True)
    guest_name = models.CharField(max_length=100, blank=True)
    started_at = models.DateTimeField(default=timezone.now)
    submitted_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.IN_PROGRESS)

    # Snapshot of the quiz rules at the moment the attempt starts.
    total_questions = models.PositiveSmallIntegerField(default=0)
    seconds_per_question = models.PositiveSmallIntegerField(default=30)
    correct_mark = models.DecimalField(max_digits=4, decimal_places=2, default=Decimal('1.00'))
    negative_mark = models.DecimalField(max_digits=4, decimal_places=2, default=Decimal('0.50'))

    score = models.DecimalField(max_digits=7, decimal_places=2, default=0)
    correct_count = models.PositiveSmallIntegerField(default=0)
    wrong_count = models.PositiveSmallIntegerField(default=0)
    unanswered_count = models.PositiveSmallIntegerField(default=0)
    time_taken_seconds = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ['-started_at']

    def __str__(self):
        return f'{self.quiz.title} - {self.display_name}'

    @property
    def is_guest(self):
        return self.student_id is None

    @property
    def display_name(self):
        if self.student_id:
            return self.student.display_name
        return self.guest_name or 'Guest'

    @property
    def answered_count(self):
        return self.correct_count + self.wrong_count

    @property
    def total_seconds(self):
        return self.seconds_per_question * self.total_questions

    @property
    def deadline(self):
        return self.started_at + timedelta(seconds=self.total_seconds)

    def is_expired(self, now=None):
        return (now or timezone.now()) >= self.deadline


class AttemptAnswer(models.Model):
    attempt = models.ForeignKey(Attempt, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.PROTECT)
    position = models.PositiveSmallIntegerField(default=0)
    selected_option = models.CharField(
        max_length=1, blank=True,
        choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')]
    )
    is_correct = models.BooleanField(null=True, blank=True)
    answered_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['position']
        constraints = [
            # The same question can never appear twice in one attempt.
            models.UniqueConstraint(fields=['attempt', 'question'], name='unique_question_per_attempt'),
            models.UniqueConstraint(fields=['attempt', 'position'], name='unique_position_per_attempt'),
        ]

    def __str__(self):
        return f'Attempt {self.attempt_id} - Question {self.question_id}'


class TeamMember(models.Model):
    """A person shown on the public "About Us" page. Edited from Admin Panel > Team."""
    name = models.CharField(max_length=120)
    name_bn = models.CharField('name (Bangla)', max_length=120, blank=True)
    role = models.CharField(max_length=120)
    role_bn = models.CharField('role (Bangla)', max_length=120, blank=True)
    bio = models.TextField('work / about', blank=True)
    bio_bn = models.TextField('work / about (Bangla)', blank=True)
    photo_url = models.URLField('photo link (optional)', max_length=500, blank=True)
    order = models.PositiveSmallIntegerField('order (small number comes first)', default=0)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['order', 'id']

    def __str__(self):
        return self.name

    @property
    def initial(self):
        return (self.name_bn or self.name or '?').strip()[:1]


class AboutPage(models.Model):
    """Text of the public About Us page. One row only; edited from Admin Panel > About page."""
    heading = models.CharField(max_length=160, blank=True)
    heading_bn = models.CharField('heading (Bangla)', max_length=160, blank=True)
    intro = models.TextField('short intro', blank=True)
    intro_bn = models.TextField('short intro (Bangla)', blank=True)
    story = models.TextField('our story / mission', blank=True)
    story_bn = models.TextField('our story / mission (Bangla)', blank=True)
    contact_email = models.EmailField('contact email', blank=True)

    def __str__(self):
        return 'About page'

    @classmethod
    def load(cls):
        obj = cls.objects.first()
        return obj or cls.objects.create()
