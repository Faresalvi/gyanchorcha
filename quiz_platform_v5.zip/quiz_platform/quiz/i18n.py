"""Tiny translation helper (English <-> Bangla) - no extra tools needed.

Texts are written in English in the templates/views. If the visitor chose
Bangla, the English text is looked up in TRANSLATIONS (quiz/translations.py).
To translate a new sentence, add one line to that file.
"""
from django.conf import settings

from .translations import TRANSLATIONS


def get_lang(request):
    return request.session.get('lang') or getattr(settings, 'DEFAULT_SITE_LANGUAGE', 'bn')


MISSING = set()  # untranslated texts seen while running (used by the tests)


def translate(lang, text):
    if lang == 'bn':
        if text in TRANSLATIONS:
            return TRANSLATIONS[text]
        if isinstance(text, str) and text.strip():
            MISSING.add(text)
    return text


def t(request, text):
    """Translate a message in a view."""
    return translate(get_lang(request), text)
