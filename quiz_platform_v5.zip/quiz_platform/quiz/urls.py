from django.urls import path

from . import panel_views as panel
from . import views

urlpatterns = [
    # public
    path('', views.home, name='home'),
    path('lang/<str:code>/', views.set_language, name='set_language'),
    path('quizzes/', views.quiz_list, name='quiz_list'),
    path('quiz/<int:quiz_id>/', views.quiz_detail, name='quiz_detail'),
    path('quiz/<int:quiz_id>/start/', views.quiz_start, name='quiz_start'),
    path('attempt/<int:attempt_id>/', views.play, name='play'),
    path('attempt/<int:attempt_id>/result/', views.result, name='result'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('about/', views.about, name='about'),
    # student account
    path('register/', views.register, name='register'),
    path('login/', views.student_login, name='student_login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # admin panel
    path('panel/login/', panel.panel_login, name='panel_login'),
    path('panel/', panel.dashboard, name='panel_dashboard'),

    path('panel/students/', panel.student_list, name='panel_students'),
    path('panel/students/new/', panel.student_create, name='panel_student_new'),
    path('panel/students/<int:pk>/', panel.student_detail, name='panel_student_detail'),
    path('panel/students/<int:pk>/edit/', panel.student_edit, name='panel_student_edit'),
    path('panel/students/<int:pk>/toggle/', panel.student_toggle, name='panel_student_toggle'),
    path('panel/students/<int:pk>/delete/', panel.student_delete, name='panel_student_delete'),

    path('panel/categories/', panel.category_list, name='panel_categories'),
    path('panel/categories/new/', panel.category_edit, name='panel_category_new'),
    path('panel/categories/<int:pk>/edit/', panel.category_edit, name='panel_category_edit'),
    path('panel/categories/<int:pk>/toggle/', panel.category_toggle, name='panel_category_toggle'),
    path('panel/categories/<int:pk>/delete/', panel.category_delete, name='panel_category_delete'),

    path('panel/questions/', panel.question_list, name='panel_questions'),
    path('panel/questions/new/', panel.question_edit, name='panel_question_new'),
    path('panel/questions/<int:pk>/edit/', panel.question_edit, name='panel_question_edit'),
    path('panel/questions/<int:pk>/toggle/', panel.question_toggle, name='panel_question_toggle'),
    path('panel/questions/<int:pk>/delete/', panel.question_delete, name='panel_question_delete'),

    path('panel/quizzes/', panel.quiz_list, name='panel_quizzes'),
    path('panel/quizzes/new/', panel.quiz_edit, name='panel_quiz_new'),
    path('panel/quizzes/<int:pk>/edit/', panel.quiz_edit, name='panel_quiz_edit'),
    path('panel/quizzes/<int:pk>/toggle/', panel.quiz_toggle, name='panel_quiz_toggle'),
    path('panel/quizzes/<int:pk>/delete/', panel.quiz_delete, name='panel_quiz_delete'),

    path('panel/team/', panel.team_list, name='panel_team'),
    path('panel/team/new/', panel.team_edit, name='panel_team_new'),
    path('panel/team/<int:pk>/edit/', panel.team_edit, name='panel_team_edit'),
    path('panel/team/<int:pk>/toggle/', panel.team_toggle, name='panel_team_toggle'),
    path('panel/team/<int:pk>/delete/', panel.team_delete, name='panel_team_delete'),

    path('panel/about/', panel.about_edit, name='panel_about'),

    path('panel/results/', panel.result_list, name='panel_results'),
    path('panel/results/<int:pk>/', panel.result_detail, name='panel_result_detail'),

    path('panel/import/', panel.import_questions_view, name='panel_import'),
    path('panel/import/template/', panel.import_template, name='panel_import_template'),
    path('panel/import/confirm/', panel.import_confirm, name='panel_import_confirm'),
]
