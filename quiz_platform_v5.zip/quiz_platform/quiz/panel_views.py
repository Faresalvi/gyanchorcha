"""Simple admin panel (/panel/) for non-technical team members."""
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.db.models.deletion import ProtectedError
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST

from .decorators import admin_required
from .forms import (AboutPageForm, CategoryForm, ExcelUploadForm, LoginForm, QuestionForm, QuizForm,
                    StudentCreateForm, StudentEditForm, TeamMemberForm)
from .i18n import t
from .models import AboutPage, Attempt, Category, Question, Quiz, TeamMember, User
from .services import (build_excel_template, build_leaderboard, finalize_expired,
                       import_questions, parse_excel)

BACKEND = 'quiz.backends.EmailBackend'


# ------------------------------------------------------------------ helpers
def _page(request, queryset, per_page=25):
    return Paginator(queryset, per_page).get_page(request.GET.get('page'))


def _query_without_page(request):
    params = request.GET.copy()
    params.pop('page', None)
    return params.urlencode()


def _cell(text, badge=None):
    return {'text': text, 'badge': badge}


def _status_cell(request, active, on='Active', off='Inactive'):
    return _cell(t(request, on if active else off), 'green' if active else 'grey')


def _action(request, label, url, kind='link', style='', confirm=''):
    return {'label': t(request, label), 'url': url, 'kind': kind, 'style': style,
            'confirm': t(request, confirm) if confirm else ''}


def _list_page(request, title, columns, rows, page, filters=None, new_url=None, new_label='',
               intro=''):
    return render(request, 'panel/list.html', {
        'title': title, 'columns': columns, 'rows': rows, 'page': page,
        'filters': filters or [], 'new_url': new_url, 'new_label': new_label,
        'querystring': _query_without_page(request), 'intro': intro})


def _edit(request, form_class, instance, title, back_url, success, extra_save=None):
    form = form_class(request.POST or None, instance=instance)
    if request.method == 'POST' and form.is_valid():
        obj = form.save(commit=False)
        if extra_save:
            extra_save(obj)
        obj.save()
        form.save_m2m()
        messages.success(request, t(request, success))
        return redirect(back_url)
    return render(request, 'panel/form.html', {'form': form, 'title': title, 'back_url': back_url})


def _delete(request, obj, title, back_url, label, success, blocked_message):
    if request.method == 'POST':
        try:
            obj.delete()
        except ProtectedError:
            messages.error(request, t(request, blocked_message))
            return redirect(back_url)
        messages.success(request, t(request, success))
        return redirect(back_url)
    return render(request, 'panel/confirm_delete.html', {
        'title': title, 'label': label, 'back_url': back_url})


# -------------------------------------------------------------- admin login
def panel_login(request):
    if request.user.is_authenticated and request.user.is_platform_admin():
        return redirect('panel_dashboard')
    form = LoginForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = authenticate(request, username=form.cleaned_data['email'],
                            password=form.cleaned_data['password'])
        if user is None:
            form.add_error(None, t(request, 'Wrong email or password, or the account is disabled.'))
        elif not user.is_platform_admin():
            form.add_error(None, t(request, 'This login is only for admins. Students please use the Student Login page.'))
        else:
            login(request, user, backend=BACKEND)
            target = request.POST.get('next') or request.GET.get('next') or ''
            if not (target and url_has_allowed_host_and_scheme(target, allowed_hosts={request.get_host()})):
                target = reverse('panel_dashboard')
            return redirect(target)
    return render(request, 'auth/admin_login.html', {'form': form, 'next': request.GET.get('next', '')})


# ---------------------------------------------------------------- dashboard
@admin_required
def dashboard(request):
    finalize_expired()
    done = Attempt.objects.filter(status=Attempt.Status.SUBMITTED)
    return render(request, 'panel/dashboard.html', {
        'cards': [
            ('Total students', User.objects.filter(role=User.Role.STUDENT, is_superuser=False).count(), 'panel_students'),
            ('Total questions', Question.objects.count(), 'panel_questions'),
            ('Total categories', Category.objects.count(), 'panel_categories'),
            ('Total quizzes', Quiz.objects.count(), 'panel_quizzes'),
            ('Total attempts', done.count(), 'panel_results'),
        ],
        'recent': done.select_related('student', 'quiz')[:8],
        'top': build_leaderboard(limit=5),
    })


# ----------------------------------------------------------------- students
def _students():
    return User.objects.filter(role=User.Role.STUDENT, is_superuser=False)


@admin_required
def student_list(request):
    q = request.GET.get('q', '').strip()
    qs = _students().annotate(attempts=Count('quiz_attempts')).order_by('-date_joined')
    if q:
        qs = qs.filter(Q(first_name__icontains=q) | Q(username__icontains=q) | Q(email__icontains=q))
    page = _page(request, qs)
    rows = []
    for s in page:
        rows.append({'cells': [
            _cell(s.display_name), _cell(s.username), _cell(s.email), _cell(s.attempts),
            _status_cell(request, s.is_active, 'Active', 'Disabled'),
            _cell(s.date_joined.strftime('%d %b %Y'))],
            'actions': [
                _action(request, 'View', reverse('panel_student_detail', args=[s.pk])),
                _action(request, 'Edit', reverse('panel_student_edit', args=[s.pk])),
                _action(request, 'Enable' if not s.is_active else 'Disable',
                        reverse('panel_student_toggle', args=[s.pk]), 'post'),
                _action(request, 'Delete', reverse('panel_student_delete', args=[s.pk]), 'link', 'danger'),
            ]})
    columns = ['Name', 'Username', 'Email', 'Attempts', 'Status', 'Joined']
    filters = [{'name': 'q', 'label': 'Search name, username or email', 'type': 'text', 'value': q}]
    return _list_page(request, 'Students', columns, rows, page, filters,
                      new_url=reverse('panel_student_new'), new_label='Add student')


@admin_required
def student_detail(request, pk):
    student = get_object_or_404(_students(), pk=pk)
    finalize_expired()
    attempts = Attempt.objects.filter(student=student, status=Attempt.Status.SUBMITTED).select_related('quiz')
    return render(request, 'panel/student_detail.html', {'student': student, 'attempts': attempts})


@admin_required
def student_create(request):
    return _edit(request, StudentCreateForm, None, 'Add student', reverse('panel_students'),
                 'Student added.')


@admin_required
def student_edit(request, pk):
    student = get_object_or_404(_students(), pk=pk)
    return _edit(request, StudentEditForm, student, 'Edit student', reverse('panel_students'),
                 'Student updated.')


@admin_required
@require_POST
def student_toggle(request, pk):
    student = get_object_or_404(_students(), pk=pk)
    student.is_active = not student.is_active
    student.save(update_fields=['is_active'])
    messages.success(request, t(request, 'Student account enabled.' if student.is_active
                                else 'Student account disabled.'))
    return redirect('panel_students')


@admin_required
def student_delete(request, pk):
    student = get_object_or_404(_students(), pk=pk)
    return _delete(request, student, 'Delete student', reverse('panel_students'),
                   f'{student.display_name} ({student.email}) - all quiz attempts of this student will be deleted too.',
                   'Student deleted.', 'This student cannot be deleted.')


# --------------------------------------------------------------- categories
@admin_required
def category_list(request):
    qs = Category.objects.annotate(total=Count('questions')).order_by('name')
    page = _page(request, qs)
    rows = []
    for c in page:
        rows.append({'cells': [_cell(c.name), _cell(c.name_bn or '-'), _cell(c.total),
                               _status_cell(request, c.is_active)],
                     'actions': [
                         _action(request, 'Edit', reverse('panel_category_edit', args=[c.pk])),
                         _action(request, 'Deactivate' if c.is_active else 'Activate',
                                 reverse('panel_category_toggle', args=[c.pk]), 'post'),
                         _action(request, 'Delete', reverse('panel_category_delete', args=[c.pk]), 'link', 'danger'),
                     ]})
    return _list_page(request, 'Categories', ['Category', 'Bangla name', 'Questions', 'Status'],
                      rows, page, new_url=reverse('panel_category_new'), new_label='Add category')


@admin_required
def category_edit(request, pk=None):
    instance = get_object_or_404(Category, pk=pk) if pk else None
    return _edit(request, CategoryForm, instance, 'Edit category' if pk else 'Add category',
                 reverse('panel_categories'), 'Category saved.')


@admin_required
@require_POST
def category_toggle(request, pk):
    c = get_object_or_404(Category, pk=pk)
    c.is_active = not c.is_active
    c.save(update_fields=['is_active'])
    messages.success(request, t(request, 'Category updated.'))
    return redirect('panel_categories')


@admin_required
def category_delete(request, pk):
    c = get_object_or_404(Category, pk=pk)
    return _delete(request, c, 'Delete category', reverse('panel_categories'), c.name,
                   'Category deleted.',
                   'This category still has questions. Move or delete them first, or make the category inactive.')


# ---------------------------------------------------------------- questions
@admin_required
def question_list(request):
    q = request.GET.get('q', '').strip()
    cat = request.GET.get('category', '')
    status = request.GET.get('status', '')
    qs = Question.objects.select_related('category')
    if q:
        qs = qs.filter(Q(question_text__icontains=q) | Q(question_text_bn__icontains=q))
    if cat.isdigit():
        qs = qs.filter(category_id=int(cat))
    if status in ('active', 'inactive'):
        qs = qs.filter(is_active=(status == 'active'))
    page = _page(request, qs)
    rows = []
    for item in page:
        text = item.question_text if len(item.question_text) <= 90 else item.question_text[:90] + '...'
        rows.append({'cells': [_cell(item.pk), _cell(text), _cell(item.category.name),
                               _cell(item.correct_option), _status_cell(request, item.is_active)],
                     'actions': [
                         _action(request, 'Edit', reverse('panel_question_edit', args=[item.pk])),
                         _action(request, 'Deactivate' if item.is_active else 'Activate',
                                 reverse('panel_question_toggle', args=[item.pk]), 'post'),
                         _action(request, 'Delete', reverse('panel_question_delete', args=[item.pk]), 'link', 'danger'),
                     ]})
    filters = [
        {'name': 'q', 'label': 'Search question', 'type': 'text', 'value': q},
        {'name': 'category', 'label': 'Category', 'type': 'select', 'value': cat,
         'options': [(str(c.pk), c.name) for c in Category.objects.all()]},
        {'name': 'status', 'label': 'Status', 'type': 'select', 'value': status,
         'options': [('active', t(request, 'Active')), ('inactive', t(request, 'Inactive'))]},
    ]
    return _list_page(request, 'Questions', ['ID', 'Question', 'Category', 'Answer', 'Status'],
                      rows, page, filters, reverse('panel_question_new'), 'Add question')


@admin_required
def question_edit(request, pk=None):
    instance = get_object_or_404(Question, pk=pk) if pk else None
    return _edit(request, QuestionForm, instance, 'Edit question' if pk else 'Add question',
                 reverse('panel_questions'), 'Question saved.')


@admin_required
@require_POST
def question_toggle(request, pk):
    item = get_object_or_404(Question, pk=pk)
    item.is_active = not item.is_active
    item.save(update_fields=['is_active'])
    messages.success(request, t(request, 'Question updated.'))
    return redirect('panel_questions')


@admin_required
def question_delete(request, pk):
    item = get_object_or_404(Question, pk=pk)
    return _delete(request, item, 'Delete question', reverse('panel_questions'),
                   item.question_text[:120], 'Question deleted.',
                   'This question was used in quiz attempts, so it cannot be deleted. Make it inactive instead.')


# ------------------------------------------------------------------ quizzes
@admin_required
def quiz_list(request):
    page = _page(request, Quiz.objects.prefetch_related('categories').annotate(tries=Count('attempts')))
    rows = []
    for quiz in page:
        cats = ', '.join(c.name for c in quiz.categories.all()) or t(request, 'All categories')
        rows.append({'cells': [
            _cell(quiz.title), _cell(cats), _cell(quiz.question_count),
            _cell(f'{quiz.seconds_per_question}s / {t(request, "question")} ({quiz.total_minutes} {t(request, "min")})'),
            _cell(f'+{quiz.correct_mark:.2f} / -{quiz.negative_mark:.2f}'),
            _cell(t(request, 'Yes') if quiz.allow_retake else t(request, 'No')),
            _status_cell(request, quiz.is_published, 'Published', 'Draft')],
            'actions': [
                _action(request, 'Edit', reverse('panel_quiz_edit', args=[quiz.pk])),
                _action(request, 'Unpublish' if quiz.is_published else 'Publish',
                        reverse('panel_quiz_toggle', args=[quiz.pk]), 'post'),
                _action(request, 'Results', reverse('panel_results') + f'?quiz={quiz.pk}'),
                _action(request, 'Delete', reverse('panel_quiz_delete', args=[quiz.pk]), 'link', 'danger'),
            ]})
    columns = ['Quiz', 'Categories', 'Questions', 'Time', 'Marks (right / wrong)', 'Retake', 'Status']
    return _list_page(request, 'Quizzes', columns, rows, page,
                      new_url=reverse('panel_quiz_new'), new_label='Create quiz')


@admin_required
def quiz_edit(request, pk=None):
    instance = get_object_or_404(Quiz, pk=pk) if pk else None

    def stamp(obj):
        if not obj.created_by_id:
            obj.created_by = request.user

    return _edit(request, QuizForm, instance, 'Edit quiz' if pk else 'Create quiz',
                 reverse('panel_quizzes'), 'Quiz saved.', extra_save=stamp)


@admin_required
@require_POST
def quiz_toggle(request, pk):
    from .services import eligible_questions
    quiz = get_object_or_404(Quiz, pk=pk)
    if not quiz.is_published and eligible_questions(quiz).count() < quiz.question_count:
        messages.error(request, t(request, 'Not enough active questions for this quiz. Add more questions or lower the total.'))
        return redirect('panel_quizzes')
    quiz.is_published = not quiz.is_published
    quiz.save(update_fields=['is_published'])
    messages.success(request, t(request, 'Quiz published.' if quiz.is_published else 'Quiz unpublished.'))
    return redirect('panel_quizzes')


@admin_required
def quiz_delete(request, pk):
    quiz = get_object_or_404(Quiz, pk=pk)
    return _delete(request, quiz, 'Delete quiz', reverse('panel_quizzes'), quiz.title, 'Quiz deleted.',
                   'This quiz already has attempts, so it cannot be deleted. Unpublish it instead.')


# ------------------------------------------------------------------ results
@admin_required
def result_list(request):
    finalize_expired()
    q = request.GET.get('q', '').strip()
    quiz_id = request.GET.get('quiz', '')
    who = request.GET.get('who', '')
    qs = Attempt.objects.filter(status=Attempt.Status.SUBMITTED).select_related('student', 'quiz')
    if q:
        qs = qs.filter(Q(student__first_name__icontains=q) | Q(student__username__icontains=q)
                       | Q(student__email__icontains=q) | Q(guest_name__icontains=q))
    if quiz_id.isdigit():
        qs = qs.filter(quiz_id=int(quiz_id))
    if who == 'student':
        qs = qs.filter(student__isnull=False)
    elif who == 'guest':
        qs = qs.filter(student__isnull=True)
    page = _page(request, qs)
    rows = []
    for a in page:
        name = a.display_name + (f' ({t(request, "Guest")})' if a.is_guest else '')
        rows.append({'cells': [
            _cell(name), _cell(a.quiz.title), _cell(f'{a.score:.2f}'),
            _cell(f'{a.correct_count} / {a.wrong_count} / {a.unanswered_count}'),
            _cell(f'{a.time_taken_seconds // 60}:{a.time_taken_seconds % 60:02d}'),
            _cell(a.started_at.astimezone().strftime('%d %b %Y %H:%M'))],
            'actions': [_action(request, 'View', reverse('panel_result_detail', args=[a.pk]))]})
    filters = [
        {'name': 'q', 'label': 'Search student', 'type': 'text', 'value': q},
        {'name': 'quiz', 'label': 'Quiz', 'type': 'select', 'value': quiz_id,
         'options': [(str(z.pk), z.title) for z in Quiz.objects.all()]},
        {'name': 'who', 'label': 'Who', 'type': 'select', 'value': who,
         'options': [('student', t(request, 'Students')), ('guest', t(request, 'Guests'))]},
    ]
    return _list_page(request, 'Results', ['Student', 'Quiz', 'Score', 'Right / Wrong / Skipped', 'Time', 'Date'],
                      rows, page, filters)


@admin_required
def result_detail(request, pk):
    attempt = get_object_or_404(Attempt.objects.select_related('student', 'quiz'), pk=pk)
    if attempt.status != Attempt.Status.SUBMITTED:
        from .services import finalize_attempt
        if attempt.is_expired():
            attempt = finalize_attempt(attempt)
    answers = attempt.answers.select_related('question__category').order_by('position')
    return render(request, 'panel/result_detail.html', {'attempt': attempt, 'answers': answers})


# -------------------------------------------------------------- Excel import
@admin_required
def import_template(request):
    response = HttpResponse(
        build_excel_template(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename="question_template.xlsx"'
    return response


@admin_required
def import_questions_view(request):
    form = ExcelUploadForm(request.POST or None, request.FILES or None)
    preview = None
    if request.method == 'POST' and form.is_valid():
        try:
            valid, errors, total = parse_excel(form.cleaned_data['file'])
        except Exception:
            form.add_error('file', t(request, 'This file could not be read. Please use the downloadable template.'))
        else:
            request.session['import_rows'] = valid
            known = {c.name.lower() for c in Category.objects.all()}
            new_cats = sorted({r['category'] for r in valid if r['category'].lower() not in known})
            preview = {'valid': valid[:50], 'valid_count': len(valid), 'errors': errors,
                       'total': total, 'new_categories': new_cats}
    return render(request, 'panel/import.html', {'form': form, 'preview': preview})


@admin_required
@require_POST
def import_confirm(request):
    rows = request.session.pop('import_rows', [])
    if not rows:
        messages.error(request, t(request, 'Nothing to import. Please upload the file again.'))
        return redirect('panel_import')
    count, new_cats = import_questions(rows)
    messages.success(request, f'{count} ' + t(request, 'questions imported.'))
    if new_cats:
        messages.success(request, f'{new_cats} ' + t(request, 'new categories created.'))
    return redirect('panel_questions')


# --------------------------------------------------------------------- team
@admin_required
def team_list(request):
    page = _page(request, TeamMember.objects.all())
    rows = []
    for m in page:
        rows.append({'cells': [_cell(m.name_bn or m.name), _cell(m.role_bn or m.role), _cell(m.order),
                               _status_cell(request, m.is_active, 'Shown', 'Hidden')],
                     'actions': [
                         _action(request, 'Edit', reverse('panel_team_edit', args=[m.pk])),
                         _action(request, 'Hide' if m.is_active else 'Show',
                                 reverse('panel_team_toggle', args=[m.pk]), 'post'),
                         _action(request, 'Delete', reverse('panel_team_delete', args=[m.pk]), 'link', 'danger'),
                     ]})
    return _list_page(request, 'Team', ['Name', 'Role', 'Order', 'Status'], rows, page,
                      new_url=reverse('panel_team_new'), new_label='Add team member',
                      intro='These people are shown on the public About Us page.')


@admin_required
def team_edit(request, pk=None):
    instance = get_object_or_404(TeamMember, pk=pk) if pk else None
    return _edit(request, TeamMemberForm, instance, 'Edit team member' if pk else 'Add team member',
                 reverse('panel_team'), 'Team member saved.')


@admin_required
@require_POST
def team_toggle(request, pk):
    m = get_object_or_404(TeamMember, pk=pk)
    m.is_active = not m.is_active
    m.save(update_fields=['is_active'])
    messages.success(request, t(request, 'Team member updated.'))
    return redirect('panel_team')


@admin_required
def team_delete(request, pk):
    m = get_object_or_404(TeamMember, pk=pk)
    return _delete(request, m, 'Delete team member', reverse('panel_team'), m.name,
                   'Team member deleted.', 'This team member cannot be deleted.')


# --------------------------------------------------------------- about page
@admin_required
def about_edit(request):
    return _edit(request, AboutPageForm, AboutPage.load(), 'About page text',
                 reverse('panel_about'), 'About page saved.')
