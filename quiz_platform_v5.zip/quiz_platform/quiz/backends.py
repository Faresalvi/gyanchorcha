from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend


class EmailBackend(ModelBackend):
    """Log in with e-mail address (a username also works, e.g. for /django-admin/)."""

    def authenticate(self, request, username=None, password=None, **kwargs):
        if not username or password is None:
            return None
        User = get_user_model()
        username = username.strip()
        user = (User.objects.filter(email__iexact=username).first()
                or User.objects.filter(username__iexact=username).first())
        if user and user.check_password(password) and self.user_can_authenticate(user):
            return user
        return None
