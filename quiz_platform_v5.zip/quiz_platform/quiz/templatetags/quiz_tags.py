from django import template

from ..i18n import translate

register = template.Library()


@register.simple_tag(takes_context=True)
def tr(context, text):
    """{% tr 'Login' %} -> 'লগইন' when the site language is Bangla."""
    return translate(context.get('lang', 'bn'), text)


@register.simple_tag(takes_context=True)
def loc(context, obj, field):
    """{% loc quiz 'title' %} -> Bangla title if available, otherwise English."""
    if context.get('lang') == 'bn':
        value = getattr(obj, f'{field}_bn', '')
        if value:
            return value
    return getattr(obj, field, '')


@register.filter
def mmss(seconds):
    try:
        seconds = int(seconds)
    except (TypeError, ValueError):
        return ''
    return f'{seconds // 60}:{seconds % 60:02d}'


@register.filter
def num(value):
    """6.00 -> 6, 6.50 -> 6.5"""
    try:
        text = f'{float(value):.2f}'.rstrip('0').rstrip('.')
        return text or '0'
    except (TypeError, ValueError):
        return value
