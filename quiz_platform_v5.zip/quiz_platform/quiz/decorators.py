from functools import wraps

from django.contrib.auth.views import redirect_to_login
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect
from django.urls import reverse


def admin_required(view):
    """Only platform admins may open these pages. Students get a 403 page."""
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path(), reverse('panel_login'))
        if not request.user.is_platform_admin():
            raise PermissionDenied
        return view(request, *args, **kwargs)
    return wrapper


def student_required(view):
    """Logged-in students only. Admins are sent to their own panel."""
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path(), reverse('student_login'))
        if request.user.is_platform_admin():
            return redirect('panel_dashboard')
        return view(request, *args, **kwargs)
    return wrapper
