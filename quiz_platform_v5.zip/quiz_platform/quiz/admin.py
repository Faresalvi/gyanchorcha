from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import AboutPage, Attempt, AttemptAnswer, Category, Question, Quiz, TeamMember, User


@admin.register(User)
class QuizUserAdmin(UserAdmin):
    list_display = ('username', 'first_name', 'email', 'role', 'is_active')
    list_filter = ('role', 'is_active')
    fieldsets = UserAdmin.fieldsets + (('Role', {'fields': ('role',)}),)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'name_bn', 'is_active')


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('id', 'question_text', 'category', 'correct_option', 'is_active')
    list_filter = ('category', 'is_active')
    search_fields = ('question_text', 'question_text_bn')


@admin.register(Quiz)
class QuizAdmin(admin.ModelAdmin):
    list_display = ('title', 'question_count', 'seconds_per_question', 'allow_retake', 'is_published')


class AnswerInline(admin.TabularInline):
    model = AttemptAnswer
    extra = 0
    can_delete = False


@admin.register(Attempt)
class AttemptAdmin(admin.ModelAdmin):
    list_display = ('id', 'quiz', 'student', 'guest_name', 'score', 'status', 'started_at')
    list_filter = ('quiz', 'status')
    inlines = [AnswerInline]


@admin.register(TeamMember)
class TeamMemberAdmin(admin.ModelAdmin):
    list_display = ('name', 'role', 'order', 'is_active')


@admin.register(AboutPage)
class AboutPageAdmin(admin.ModelAdmin):
    list_display = ('__str__', 'contact_email')
