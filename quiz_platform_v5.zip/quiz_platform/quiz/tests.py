import re
from datetime import timedelta
from decimal import Decimal
from io import BytesIO
from pathlib import Path

from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from . import i18n
from .models import Attempt, AttemptAnswer, Category, Question, Quiz, TeamMember, User
from .services import (build_excel_template, build_leaderboard, calculate_score, finalize_attempt,
                       parse_excel, start_attempt)


def make_questions(n=12, category=None):
    category = category or Category.objects.create(name='General', name_bn='সাধারণ')
    for i in range(n):
        Question.objects.create(category=category, question_text=f'Q{i}', option_a='a', option_b='b',
                                option_c='c', option_d='d', correct_option='A', explanation=f'E{i}')
    return category


@override_settings(DEFAULT_SITE_LANGUAGE='en')
class Base(TestCase):
    def setUp(self):
        self.cat = make_questions(12)
        self.quiz = Quiz.objects.create(title='Test Quiz', title_bn='টেস্ট', question_count=10,
                                        seconds_per_question=30, is_published=True)
        self.student = User.objects.create_user('stu', 'stu@x.com', 'Pass12345!', first_name='Stu')
        self.other = User.objects.create_user('oth', 'oth@x.com', 'Pass12345!', first_name='Oth')
        self.admin = User.objects.create_superuser('boss', 'boss@x.com', 'Pass12345!')


class ScoringTests(Base):
    def test_example_from_documentation(self):
        # 7 correct, 2 wrong, 1 unanswered => 7 - 1 = 6
        self.assertEqual(calculate_score(7, 2, Decimal('1'), Decimal('0.5')), Decimal('6'))

    def test_finalize_counts_and_score(self):
        attempt = start_attempt(self.quiz, student=self.student)
        answers = list(attempt.answers.all())
        for i, a in enumerate(answers):
            if i < 7:
                a.selected_option = 'A'      # correct
            elif i < 9:
                a.selected_option = 'B'      # wrong
            a.answered_at = timezone.now()
            a.save()
        attempt.started_at = timezone.now() - timedelta(seconds=400)
        attempt.save()
        done = finalize_attempt(attempt)
        self.assertEqual((done.correct_count, done.wrong_count, done.unanswered_count), (7, 2, 1))
        self.assertEqual(done.score, Decimal('6.00'))
        self.assertEqual(done.status, Attempt.Status.SUBMITTED)


class RandomQuestionTests(Base):
    def test_no_duplicate_questions_and_ten_selected(self):
        for _ in range(20):
            attempt = start_attempt(self.quiz, student=self.student)
            ids = list(attempt.answers.values_list('question_id', flat=True))
            self.assertEqual(len(ids), 10)
            self.assertEqual(len(set(ids)), 10)

    def test_cannot_start_without_enough_questions(self):
        Question.objects.filter(pk__in=Question.objects.values_list('pk', flat=True)[:5]).update(is_active=False)
        self.client.force_login(self.student)
        response = self.client.post(reverse('quiz_start', args=[self.quiz.pk]), follow=True)
        self.assertEqual(Attempt.objects.count(), 0)
        self.assertContains(response, 'not enough questions')

    def test_database_blocks_duplicate_question(self):
        from django.db import IntegrityError, transaction
        attempt = start_attempt(self.quiz, student=self.student)
        existing = attempt.answers.first()
        with self.assertRaises(IntegrityError), transaction.atomic():
            AttemptAnswer.objects.create(attempt=attempt, question=existing.question, position=99)


class PlayTimerTests(Base):
    def start(self):
        self.client.force_login(self.student)
        self.client.post(reverse('quiz_start', args=[self.quiz.pk]))
        return Attempt.objects.get()

    def test_answer_saved_and_moves_to_next_question(self):
        attempt = self.start()
        url = reverse('play', args=[attempt.pk])
        r = self.client.post(url, {'position': 0, 'choice': 'B'}, follow=True)
        self.assertEqual(r.redirect_chain[-1][0], url + '?q=2')
        self.assertEqual(attempt.answers.get(position=0).selected_option, 'B')
        self.assertContains(r, 'Question 2 / 10')

    def test_can_go_back_and_change_answer(self):
        attempt = self.start()
        url = reverse('play', args=[attempt.pk])
        self.client.post(url, {'position': 0, 'choice': 'B'})
        r = self.client.get(url + '?q=1')
        self.assertContains(r, 'Question 1 / 10')
        self.client.post(url, {'position': 0, 'choice': 'C'})
        self.assertEqual(attempt.answers.get(position=0).selected_option, 'C')

    def test_time_is_shared_so_old_question_still_open_after_30_seconds(self):
        attempt = self.start()
        attempt.started_at = timezone.now() - timedelta(seconds=31)
        attempt.save()
        url = reverse('play', args=[attempt.pk])
        # still question 1 (no auto jump), and question 1 can still be answered
        self.assertContains(self.client.get(url), 'Question 1 / 10')
        self.client.post(url, {'position': 0, 'choice': 'A'})
        self.assertEqual(attempt.answers.get(position=0).selected_option, 'A')

    def test_default_question_is_first_unanswered_and_bad_q_is_ignored(self):
        attempt = self.start()
        url = reverse('play', args=[attempt.pk])
        self.client.post(url, {'position': 0, 'choice': 'A'})
        self.client.post(url, {'position': 1, 'choice': 'A'})
        self.assertContains(self.client.get(url), 'Question 3 / 10')
        self.assertContains(self.client.get(url + '?q=999'), 'Question 3 / 10')
        self.assertContains(self.client.get(url + '?q=abc'), 'Question 3 / 10')

    def test_last_question_stays_and_finish_early_submits(self):
        attempt = self.start()
        url = reverse('play', args=[attempt.pk])
        r = self.client.post(url, {'position': 9, 'choice': 'A'}, follow=True)
        self.assertEqual(r.redirect_chain[-1][0], url + '?q=10')
        r = self.client.post(url, {'action': 'finish'})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r['Location'].endswith('/result/#join'))
        attempt.refresh_from_db()
        self.assertEqual(attempt.status, Attempt.Status.SUBMITTED)
        self.assertEqual(attempt.correct_count, 1)
        self.assertEqual(attempt.unanswered_count, 9)

    def test_invalid_choice_is_rejected(self):
        attempt = self.start()
        url = reverse('play', args=[attempt.pk])
        self.client.post(url, {'position': 0, 'choice': 'Z'})
        self.assertEqual(attempt.answers.get(position=0).selected_option, '')

    def test_does_not_leak_correct_answer_while_playing(self):
        attempt = self.start()
        r = self.client.get(reverse('play', args=[attempt.pk]))
        self.assertNotContains(r, 'E0')  # explanation hidden
        self.assertContains(r, 'id="timer"')
        self.assertContains(r, 'data-remaining="300"')

    def test_auto_submit_after_total_time(self):
        attempt = self.start()
        attempt.started_at = timezone.now() - timedelta(seconds=301)
        attempt.save()
        r = self.client.get(reverse('play', args=[attempt.pk]))
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r['Location'].endswith('/result/#join'))
        attempt.refresh_from_db()
        self.assertEqual(attempt.status, Attempt.Status.SUBMITTED)
        self.assertEqual(attempt.unanswered_count, 10)

    def test_result_not_available_before_time_ends(self):
        attempt = self.start()
        r = self.client.get(reverse('result', args=[attempt.pk]))
        self.assertRedirects(r, reverse('play', args=[attempt.pk]))

    def test_retake_gets_new_set_and_blocked_when_disallowed(self):
        self.client.force_login(self.student)
        self.client.post(reverse('quiz_start', args=[self.quiz.pk]))
        first = Attempt.objects.get()
        first.started_at = timezone.now() - timedelta(seconds=400)
        first.save()
        finalize_attempt(first)
        self.client.post(reverse('quiz_start', args=[self.quiz.pk]))
        self.assertEqual(Attempt.objects.count(), 2)
        self.quiz.allow_retake = False
        self.quiz.save()
        for a in Attempt.objects.exclude(status='SUBMITTED'):
            a.started_at = timezone.now() - timedelta(seconds=400)
            a.save()
            finalize_attempt(a)
        self.client.post(reverse('quiz_start', args=[self.quiz.pk]))
        self.assertEqual(Attempt.objects.count(), 2)


class GuestTests(Base):
    def test_guest_flow_saved_and_claimed_on_register(self):
        r = self.client.post(reverse('quiz_start', args=[self.quiz.pk]), {'name': 'Rahim'})
        attempt = Attempt.objects.get()
        self.assertIsNone(attempt.student)
        self.assertEqual(attempt.guest_name, 'Rahim')
        self.assertRedirects(r, reverse('play', args=[attempt.pk]))
        attempt.started_at = timezone.now() - timedelta(seconds=400)
        attempt.save()
        result = self.client.get(reverse('result', args=[attempt.pk]))
        self.assertContains(result, 'id="join"')            # popup
        self.assertContains(result, 'href="#"')              # cancel option
        # guest appears on leaderboard
        board = self.client.get(reverse('leaderboard'))
        self.assertContains(board, 'Rahim')
        # registering links the guest attempt to the new account
        self.client.post(reverse('register'), {
            'username': 'rahim', 'first_name': 'Rahim', 'email': 'rahim@x.com',
            'password1': 'Strong#Pass2026', 'password2': 'Strong#Pass2026'})
        attempt.refresh_from_db()
        self.assertEqual(attempt.student.username, 'rahim')
        dash = self.client.get(reverse('dashboard'))
        self.assertContains(dash, 'Test Quiz')

    def test_guest_needs_name(self):
        self.client.post(reverse('quiz_start', args=[self.quiz.pk]), {'name': ''})
        self.assertEqual(Attempt.objects.count(), 0)

    def test_other_guest_cannot_open_attempt(self):
        self.client.post(reverse('quiz_start', args=[self.quiz.pk]), {'name': 'A'})
        attempt = Attempt.objects.get()
        from django.test import Client
        self.assertEqual(Client().get(reverse('play', args=[attempt.pk])).status_code, 404)


class AuthAndPermissionTests(Base):
    def test_login_with_email(self):
        r = self.client.post(reverse('student_login'), {'email': 'STU@x.com', 'password': 'Pass12345!'})
        self.assertRedirects(r, reverse('dashboard'))

    def test_admin_cannot_use_student_login_and_student_cannot_use_admin_login(self):
        r = self.client.post(reverse('student_login'), {'email': 'boss@x.com', 'password': 'Pass12345!'})
        self.assertContains(r, 'admin account')
        r = self.client.post(reverse('panel_login'), {'email': 'stu@x.com', 'password': 'Pass12345!'})
        self.assertContains(r, 'only for admins')
        r = self.client.post(reverse('panel_login'), {'email': 'boss@x.com', 'password': 'Pass12345!'})
        self.assertRedirects(r, reverse('panel_dashboard'))

    def test_student_blocked_from_panel(self):
        self.client.force_login(self.student)
        for name in ('panel_dashboard', 'panel_students', 'panel_questions', 'panel_import'):
            self.assertEqual(self.client.get(reverse(name)).status_code, 403)

    def test_anonymous_redirected_from_panel(self):
        r = self.client.get(reverse('panel_students'))
        self.assertEqual(r.status_code, 302)
        self.assertIn('/panel/login/', r['Location'])

    def test_student_cannot_see_other_students_result(self):
        attempt = start_attempt(self.quiz, student=self.student)
        attempt.started_at = timezone.now() - timedelta(seconds=400)
        attempt.save()
        self.client.force_login(self.other)
        self.assertEqual(self.client.get(reverse('result', args=[attempt.pk])).status_code, 404)
        self.client.force_login(self.student)
        self.assertEqual(self.client.get(reverse('result', args=[attempt.pk])).status_code, 200)
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get(reverse('result', args=[attempt.pk])).status_code, 200)

    def test_disabled_student_cannot_login(self):
        self.student.is_active = False
        self.student.save()
        r = self.client.post(reverse('student_login'), {'email': 'stu@x.com', 'password': 'Pass12345!'})
        self.assertContains(r, 'disabled')

    def test_duplicate_email_rejected(self):
        r = self.client.post(reverse('register'), {
            'username': 'new', 'first_name': 'N', 'email': 'STU@x.com',
            'password1': 'Strong#Pass2026', 'password2': 'Strong#Pass2026'})
        self.assertContains(r, 'already registered')


class LeaderboardTests(Base):
    def make(self, user, correct, wrong, taken, name=''):
        a = start_attempt(self.quiz, student=user, guest_name=name)
        a.status, a.correct_count, a.wrong_count = Attempt.Status.SUBMITTED, correct, wrong
        a.score = calculate_score(correct, wrong, 1, Decimal('0.5'))
        a.time_taken_seconds, a.submitted_at = taken, timezone.now()
        a.save()
        return a

    def test_ranking_rules(self):
        third = User.objects.create_user('third', 'third@x.com', 'Pass12345!')
        a = self.make(self.student, 8, 0, 200)      # 8.0
        b = self.make(self.other, 9, 2, 150)        # 8.0, more correct -> ahead of a
        c = self.make(third, 9, 2, 100)             # 8.0, same correct, less time -> first
        g = self.make(None, 5, 0, 50, name='Guesty')
        rows = build_leaderboard()
        self.assertEqual([r.pk for r in rows], [c.pk, b.pk, a.pk, g.pk])
        self.assertEqual([r.rank for r in rows], [1, 2, 3, 4])

    def test_student_listed_once_with_best_attempt(self):
        self.make(self.student, 3, 0, 100)
        best = self.make(self.student, 9, 0, 100)
        rows = build_leaderboard()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0].pk, best.pk)


class ExcelTests(Base):
    def upload(self, wb_bytes):
        return SimpleUploadedFile('q.xlsx', wb_bytes,
                                  content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

    def test_template_parses(self):
        valid, errors, total = parse_excel(BytesIO(build_excel_template()))
        self.assertEqual((len(valid), len(errors), total), (2, 0, 2))

    def test_preview_errors_and_import(self):
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active
        ws.append(['Question', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Answer', 'Category', 'Explanation'])
        ws.append(['Good one', 1, 2, 3, 4, 'b', 'NewCat', ''])
        ws.append(['Bad answer', 'a', 'b', 'c', 'd', 'Z', 'NewCat', ''])
        ws.append(['', 'a', 'b', 'c', 'd', 'A', 'NewCat', ''])
        buf = BytesIO()
        wb.save(buf)
        self.client.force_login(self.admin)
        r = self.client.post(reverse('panel_import'), {'file': self.upload(buf.getvalue())})
        self.assertContains(r, 'Error report')
        self.assertContains(r, 'Correct Answer must be A, B, C or D')
        self.assertContains(r, 'NewCat')
        before = Question.objects.count()
        r = self.client.post(reverse('panel_import_confirm'), follow=True)
        self.assertEqual(Question.objects.count(), before + 1)
        q = Question.objects.get(question_text='Good one')
        self.assertEqual((q.correct_option, q.option_a, q.category.name), ('B', '1', 'NewCat'))

    def test_rejects_non_xlsx(self):
        self.client.force_login(self.admin)
        r = self.client.post(reverse('panel_import'), {'file': SimpleUploadedFile('q.csv', b'a,b')})
        self.assertContains(r, 'Please upload an .xlsx file')

    def test_template_download(self):
        self.client.force_login(self.admin)
        r = self.client.get(reverse('panel_import_template'))
        self.assertEqual(r.status_code, 200)
        self.assertIn('spreadsheetml', r['Content-Type'])


class PanelCrudTests(Base):
    def setUp(self):
        super().setUp()
        self.client.force_login(self.admin)

    def test_all_panel_pages_render(self):
        attempt = start_attempt(self.quiz, student=self.student)
        attempt.started_at = timezone.now() - timedelta(seconds=400)
        attempt.save()
        finalize_attempt(attempt)
        for name, args in [
            ('panel_dashboard', []), ('panel_students', []), ('panel_student_detail', [self.student.pk]),
            ('panel_student_edit', [self.student.pk]), ('panel_student_delete', [self.student.pk]),
            ('panel_categories', []), ('panel_category_new', []), ('panel_category_edit', [self.cat.pk]),
            ('panel_category_delete', [self.cat.pk]), ('panel_questions', []), ('panel_question_new', []),
            ('panel_quizzes', []), ('panel_quiz_new', []), ('panel_quiz_edit', [self.quiz.pk]),
            ('panel_quiz_delete', [self.quiz.pk]), ('panel_results', []),
            ('panel_result_detail', [attempt.pk]), ('panel_import', []),
            ('panel_team', []), ('panel_team_new', []),
        ]:
            r = self.client.get(reverse(name, args=args))
            self.assertEqual(r.status_code, 200, name)

    def test_create_quiz_and_publish_toggle(self):
        r = self.client.post(reverse('panel_quiz_new'), {
            'title': 'New', 'question_count': 10, 'seconds_per_question': 30,
            'correct_mark': '1', 'negative_mark': '0.5', 'allow_retake': 'on'})
        self.assertEqual(r.status_code, 302)
        quiz = Quiz.objects.get(title='New')
        self.assertFalse(quiz.is_published)
        self.client.post(reverse('panel_quiz_toggle', args=[quiz.pk]))
        quiz.refresh_from_db()
        self.assertTrue(quiz.is_published)

    def test_cannot_publish_quiz_without_enough_questions(self):
        quiz = Quiz.objects.create(title='Big', question_count=50)
        self.client.post(reverse('panel_quiz_toggle', args=[quiz.pk]))
        quiz.refresh_from_db()
        self.assertFalse(quiz.is_published)

    def test_student_disable_and_delete(self):
        self.client.post(reverse('panel_student_toggle', args=[self.student.pk]))
        self.student.refresh_from_db()
        self.assertFalse(self.student.is_active)
        self.client.post(reverse('panel_student_delete', args=[self.student.pk]))
        self.assertFalse(User.objects.filter(pk=self.student.pk).exists())

    def test_category_with_questions_cannot_be_deleted(self):
        self.client.post(reverse('panel_category_delete', args=[self.cat.pk]))
        self.assertTrue(Category.objects.filter(pk=self.cat.pk).exists())

    def test_add_question_manually(self):
        r = self.client.post(reverse('panel_question_new'), {
            'category': self.cat.pk, 'question_text': 'Manual?', 'option_a': '1', 'option_b': '2',
            'option_c': '3', 'option_d': '4', 'correct_option': 'D', 'is_active': 'on'})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(Question.objects.filter(question_text='Manual?', correct_option='D').exists())


class LanguageTests(Base):
    def test_switch_language(self):
        r = self.client.get(reverse('home'))
        self.assertContains(r, 'Start Quiz')
        self.client.get(reverse('set_language', args=['bn']) + '?next=/')
        r = self.client.get(reverse('home'))
        self.assertContains(r, 'কুইজ শুরু করুন')

    def test_no_open_redirect(self):
        r = self.client.get(reverse('set_language', args=['en']) + '?next=https://evil.example/')
        self.assertEqual(r['Location'], '/')

    def test_all_pages_in_both_languages_have_no_missing_translations(self):
        i18n.MISSING.clear()
        attempt = start_attempt(self.quiz, student=self.student)
        for lang in ('bn', 'en'):
            for user in (None, self.student, self.admin):
                self.client.logout()
                if user:
                    self.client.force_login(user)
                self.client.get(reverse('set_language', args=[lang]))
                urls = ['home', 'quiz_list', 'leaderboard', 'about', 'student_login', 'register', 'panel_login']
                for name in urls:
                    self.client.get(reverse(name))
                self.client.get(reverse('quiz_detail', args=[self.quiz.pk]))
                if user == self.student:
                    self.client.get(reverse('dashboard'))
                    self.client.get(reverse('play', args=[attempt.pk]))
                if user == self.admin:
                    for name in ('panel_dashboard', 'panel_students', 'panel_categories', 'panel_questions',
                                 'panel_quizzes', 'panel_results', 'panel_import', 'panel_quiz_new',
                                 'panel_question_new', 'panel_category_new', 'panel_team', 'panel_team_new'):
                        self.client.get(reverse(name))
        self.assertEqual(sorted(i18n.MISSING), [])

    def test_template_texts_all_translated(self):
        pattern = re.compile(r"""\{%\s*tr\s+(?:'([^']*)'|"([^"]*)")\s*%\}""")
        from .translations import TRANSLATIONS
        missing = set()
        for path in Path(settings.BASE_DIR, 'templates').rglob('*.html'):
            for m in pattern.finditer(path.read_text(encoding='utf-8')):
                text = m.group(1) if m.group(1) is not None else m.group(2)
                if text not in TRANSLATIONS:
                    missing.add(text)
        self.assertEqual(sorted(missing), [])


class AboutTeamTests(Base):
    def test_about_page_shows_only_active_members_in_order(self):
        TeamMember.objects.create(name='Second Person', role='Designer', order=2)
        TeamMember.objects.create(name='First Person', name_bn='প্রথম জন', role='Founder', order=1)
        TeamMember.objects.create(name='Hidden Person', role='Ghost', order=0, is_active=False)
        r = self.client.get(reverse('about'))
        self.assertContains(r, 'First Person')
        self.assertContains(r, 'Second Person')
        self.assertNotContains(r, 'Hidden Person')
        body = r.content.decode()
        self.assertLess(body.index('First Person'), body.index('Second Person'))

    def test_about_page_bangla_uses_bangla_name(self):
        TeamMember.objects.create(name='First Person', name_bn='প্রথম জন', role='Founder', role_bn='প্রতিষ্ঠাতা')
        self.client.get(reverse('set_language', args=['bn']))
        r = self.client.get(reverse('about'))
        self.assertContains(r, 'প্রথম জন')
        self.assertContains(r, 'প্রতিষ্ঠাতা')

    def test_about_empty_state(self):
        self.assertContains(self.client.get(reverse('about')), 'Team members will appear here soon.')

    def test_admin_can_add_edit_hide_delete_member(self):
        self.client.force_login(self.admin)
        r = self.client.post(reverse('panel_team_new'), {
            'name': 'Rafi', 'name_bn': 'রাফি', 'role': 'Developer', 'role_bn': 'ডেভেলপার',
            'bio': 'Builds the site', 'bio_bn': '', 'photo_url': '', 'order': 1, 'is_active': 'on'})
        self.assertEqual(r.status_code, 302)
        m = TeamMember.objects.get()
        self.client.post(reverse('panel_team_edit', args=[m.pk]), {
            'name': 'Rafi A', 'name_bn': 'রাফি', 'role': 'Developer', 'order': 1, 'is_active': 'on'})
        m.refresh_from_db()
        self.assertEqual(m.name, 'Rafi A')
        self.client.post(reverse('panel_team_toggle', args=[m.pk]))
        m.refresh_from_db()
        self.assertFalse(m.is_active)
        self.assertNotContains(self.client.get(reverse('about')), 'Rafi A')
        self.client.post(reverse('panel_team_delete', args=[m.pk]))
        self.assertEqual(TeamMember.objects.count(), 0)

    def test_student_cannot_open_team_panel(self):
        self.client.force_login(self.student)
        self.assertNotEqual(self.client.get(reverse('panel_team')).status_code, 200)
