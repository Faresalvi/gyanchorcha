"""English -> Bangla texts. To translate a new sentence, add a line: 'English': 'বাংলা',"""

TRANSLATIONS = {
    # ---- general / navigation
    'Quiz Platform': 'কুইজ প্ল্যাটফর্ম',
    'Gyanchorcha': 'জ্ঞানচর্চা',
    'Gyanchorcha - free Bangla online quiz platform for Bangladeshi students. 30 seconds per question, instant result, leaderboard.':
        'জ্ঞানচর্চা - বাংলাদেশের শিক্ষার্থীদের জন্য ফ্রি বাংলা অনলাইন কুইজ প্ল্যাটফর্ম। প্রতি প্রশ্নে ৩০ সেকেন্ড, সঙ্গে সঙ্গে ফলাফল, লিডারবোর্ডে প্রতিযোগিতা।',
    'Quizzes': 'কুইজ',
    'Leaderboard': 'লিডারবোর্ড',
    'Login': 'লগইন',
    'Logout': 'লগআউট',
    'Registration': 'রেজিস্ট্রেশন',
    'Admin Login': 'অ্যাডমিন লগইন',
    'Admin Panel': 'অ্যাডমিন প্যানেল',
    'My Dashboard': 'আমার ড্যাশবোর্ড',
    'Back to home': 'হোমে ফিরুন',
    'You do not have permission to open this page.': 'এই পেজ খোলার অনুমতি আপনার নেই।',
    'Close': 'বন্ধ করুন',
    'Back': 'ফিরে যান',
    'Cancel': 'বাতিল',
    'Save': 'সংরক্ষণ করুন',
    'Edit': 'সম্পাদনা',
    'Delete': 'মুছুন',
    'View': 'দেখুন',
    'Filter': 'ফিল্টার',
    'Clear': 'মুছে দিন',
    'All': 'সব',
    'Yes': 'হ্যাঁ',
    'No': 'না',
    'Next': 'পরবর্তী',
    'Previous': 'আগের',
    'Skip': 'এড়িয়ে যান',
    'Nothing here yet.': 'এখানে এখনো কিছু নেই।',
    'min': 'মিনিট',
    'question': 'প্রশ্ন',
    'questions': 'টি প্রশ্ন',
    'Guest': 'গেস্ট',
    'Welcome': 'স্বাগতম',

    # ---- welcome page
    'Every question you answer makes you sharper.': 'প্রতিটি প্রশ্নের উত্তর আপনাকে আরও ধারালো করে তোলে।',
    'Practice with timed quizzes, see the right answers straight away, and climb the leaderboard. Join a quiz now - no account needed.':
        'সময়সীমার কুইজে অনুশীলন করুন, সঙ্গে সঙ্গে সঠিক উত্তর দেখুন, আর লিডারবোর্ডে উপরে উঠুন। এখনই কুইজে যোগ দিন, অ্যাকাউন্ট লাগবে না।',
    'Start Quiz': 'কুইজ শুরু করুন',
    'Gyanchorcha - Free Bangla Online Quiz for Students': 'জ্ঞানচর্চা - শিক্ষার্থীদের জন্য ফ্রি বাংলা অনলাইন কুইজ',
    'Test yourself before the exam on Gyanchorcha. Free Bangla quizzes for BCS, admission and job preparation, 30 seconds per question, instant results and a leaderboard.':
        'পরীক্ষার আগে নিজেকে যাচাই করুন জ্ঞানচর্চায়। বিসিএস, ভর্তি পরীক্ষা ও চাকরির প্রস্তুতির জন্য ফ্রি বাংলা কুইজ, প্রতি প্রশ্নে ৩০ সেকেন্ড, সঙ্গে সঙ্গে ফলাফল ও লিডারবোর্ড।',
    'Learn': 'জানুন',
    'Test yourself': 'যাচাই করুন',
    'Move ahead': 'এগিয়ে যান',
    '30 seconds in the exam hall. Will the answer come back to you?': 'পরীক্ষার হলে ৩০ সেকেন্ড সময়। আপনার উত্তরটা কি মনে পড়বে?',
    'You stayed up late, made your notes, and still your mind went blank on that one question. Reading it and remembering it are not the same thing. Students who test themselves every day stay calm in the exam hall. Take just one quiz today and see where you really stand. Your classmate may already be climbing the leaderboard ahead of you!':
        'রাত জেগে পড়েছেন, নোটও করেছেন, কিন্তু পরীক্ষার হলে ঠিক সেই প্রশ্নটাতেই মাথা ফাঁকা হয়ে গেল, এমন অভিজ্ঞতা কি আপনার হয়েছে? পড়ে ফেলা আর মনে রাখা এক জিনিস নয়। যারা প্রতিদিন নিজেকে যাচাই করে, তারাই হলে ঠান্ডা মাথায় উত্তর দেয়। আজ মাত্র একটা কুইজ দিন, দেখুন আপনি সত্যিই কোথায় দাঁড়িয়ে আছেন। হয়তো আপনার সহপাঠী আজই লিডারবোর্ডে আপনার আগে উঠে যাচ্ছে!',
    'Take the challenge - start now': 'চ্যালেঞ্জ নিন, এখনই শুরু করুন',
    'Play without an account. Completely free - all you need is 30 seconds.': 'অ্যাকাউন্ট ছাড়াই খেলা যায়। সম্পূর্ণ ফ্রি, শুধু আপনার ৩০ সেকেন্ড দরকার।',
    'Create free account': 'ফ্রি অ্যাকাউন্ট খুলুন',
    'Success is the sum of small efforts, repeated day in and day out.':
        'সফলতা হলো ছোট ছোট প্রচেষ্টার যোগফল, যা প্রতিদিন বারবার করা হয়।',
    '30 seconds per question': 'প্রতি প্রশ্নে ৩০ সেকেন্ড',
    'Each question has its own countdown. Think fast, and change your answer any time before the clock runs out.':
        'প্রতিটি প্রশ্নের নিজস্ব কাউন্টডাউন আছে। দ্রুত ভাবুন, আর সময় শেষ হওয়ার আগে যেকোনো সময় উত্তর বদলান।',
    'Instant result': 'সঙ্গে সঙ্গে ফলাফল',
    'When the quiz ends you see your score, your answers and the correct answers with explanations.':
        'কুইজ শেষ হলে আপনার স্কোর, আপনার উত্তর এবং ব্যাখ্যাসহ সঠিক উত্তর দেখতে পাবেন।',
    'Higher score first. If scores are equal, more correct answers and a faster time win.':
        'বেশি স্কোর আগে। স্কোর সমান হলে বেশি সঠিক উত্তর এবং কম সময় এগিয়ে থাকে।',

    # ---- quiz list / detail
    'Choose a quiz': 'একটি কুইজ বেছে নিন',
    'Pick a category to see its quizzes.': 'বিভাগ বেছে নিন, সেই বিভাগের কুইজ দেখতে পাবেন।',
    'All categories': 'সব বিভাগ',
    'View quiz': 'কুইজ দেখুন',
    'Coming soon': 'শীঘ্রই আসছে',
    'No quiz is available in this category yet.': 'এই বিভাগে এখনো কোনো কুইজ নেই।',
    'No quiz is available right now.': 'এই মুহূর্তে কোনো কুইজ নেই।',
    'seconds per question': 'সেকেন্ড প্রতি প্রশ্নে',
    'Total questions': 'মোট প্রশ্ন',
    'Time': 'সময়',
    'Correct answer': 'সঠিক উত্তর',
    'Wrong answer': 'ভুল উত্তর',
    'Unanswered': 'উত্তর দেওয়া হয়নি',
    'Retake': 'পুনরায় দেওয়া',
    'Allowed': 'অনুমতি আছে',
    'Not allowed': 'অনুমতি নেই',
    'One question is shown at a time. You can change your answer until its time ends.':
        'একবারে একটি প্রশ্ন দেখানো হয়। সময় শেষ না হওয়া পর্যন্ত উত্তর বদলাতে পারবেন।',
    'The next question appears automatically when the time of the current question ends.':
        'বর্তমান প্রশ্নের সময় শেষ হলে পরের প্রশ্ন নিজে থেকেই আসবে।',
    'You cannot go back to an earlier question.': 'আগের প্রশ্নে ফিরে যাওয়া যাবে না।',
    'Your name': 'আপনার নাম',
    'You are taking this quiz as a guest.': 'আপনি গেস্ট হিসেবে কুইজ দিচ্ছেন।',
    'Retake is not allowed for this quiz.': 'এই কুইজ আবার দেওয়ার অনুমতি নেই।',
    'This quiz cannot start yet because there are not enough questions.':
        'যথেষ্ট প্রশ্ন না থাকায় এই কুইজ এখনো শুরু করা যাচ্ছে না।',
    'Please enter your name to start as a guest.': 'গেস্ট হিসেবে শুরু করতে আপনার নাম লিখুন।',
    'Admins cannot take quizzes. Please use a student or guest session.':
        'অ্যাডমিন কুইজ দিতে পারবেন না। স্টুডেন্ট বা গেস্ট হিসেবে দিন।',

    # ---- play
    'Question': 'প্রশ্ন',
    'Time left for this question': 'এই প্রশ্নের বাকি সময়',
    'seconds left': 'সেকেন্ড বাকি',
    'Your answer is saved. You can still change it until the time ends.':
        'আপনার উত্তর সেভ হয়েছে। সময় শেষ না হওয়া পর্যন্ত বদলাতে পারবেন।',
    'Tap an option to answer. The next question comes automatically when the time ends.':
        'উত্তর দিতে একটি অপশনে ট্যাপ করুন। সময় শেষ হলে পরের প্রশ্ন নিজে থেকেই আসবে।',
    'Time for that question was over, so the answer was not saved.':
        'ওই প্রশ্নের সময় শেষ হয়ে গিয়েছিল, তাই উত্তর সেভ হয়নি।',

    # ---- result
    'Result': 'ফলাফল',
    'Your result': 'আপনার ফলাফল',
    'Total Score': 'মোট স্কোর',
    'Total Questions': 'মোট প্রশ্ন',
    'Answered': 'উত্তর দেওয়া',
    'Correct': 'সঠিক',
    'Wrong': 'ভুল',
    'Time Taken': 'সময় লেগেছে',
    'Try again': 'আবার চেষ্টা করুন',
    'More quizzes': 'আরও কুইজ',
    'Answer review': 'উত্তর পর্যালোচনা',
    'Your answer': 'আপনার উত্তর',
    'Explanation': 'ব্যাখ্যা',
    'Keep your progress - create a free account': 'আপনার অগ্রগতি রাখুন, একটি ফ্রি অ্যাকাউন্ট খুলুন',
    'You took this quiz as a guest. Register to see all your attempts, scores and rank in one place.':
        'আপনি গেস্ট হিসেবে কুইজ দিয়েছেন। রেজিস্ট্রেশন করলে সব চেষ্টা, স্কোর ও র‍্যাংক এক জায়গায় দেখতে পাবেন।',
    'Guest attempts on this device': 'এই ডিভাইসে গেস্ট চেষ্টা',
    'they will be added to your account.': 'এগুলো আপনার অ্যাকাউন্টে যোগ হবে।',
    'Not now': 'এখন নয়',

    # ---- leaderboard
    'Ranked by score, then correct answers, then less time taken. Each student appears once with the best attempt.':
        'র‍্যাংক হয় স্কোর, তারপর সঠিক উত্তর, তারপর কম সময় অনুযায়ী। প্রতিজন স্টুডেন্ট সেরা চেষ্টা নিয়ে একবার থাকেন।',
    'All quizzes': 'সব কুইজ',
    'Rank': 'র‍্যাংক',
    'Name': 'নাম',
    'Quiz': 'কুইজ',
    'No results yet. Be the first to take a quiz!': 'এখনো কোনো ফলাফল নেই। প্রথম কুইজ দেওয়ার সুযোগ আপনার!',
    'No results yet.': 'এখনো কোনো ফলাফল নেই।',

    # ---- student dashboard
    'Total Quiz Attempts': 'মোট কুইজ চেষ্টা',
    'Best Score': 'সেরা স্কোর',
    'Correct Answers': 'সঠিক উত্তর',
    'Wrong Answers': 'ভুল উত্তর',
    'Unanswered Questions': 'উত্তরহীন প্রশ্ন',
    'My Current Rank': 'আমার বর্তমান র‍্যাংক',
    'Available Quizzes': 'উপলব্ধ কুইজ',
    'My Quiz History': 'আমার কুইজের ইতিহাস',
    'Date': 'তারিখ',
    'Review': 'পর্যালোচনা',
    'You have not taken any quiz yet.': 'আপনি এখনো কোনো কুইজ দেননি।',
    'Profile Information': 'প্রোফাইল তথ্য',
    'Username': 'ইউজারনেম',
    'Email': 'ইমেইল',
    'Member since': 'সদস্য হয়েছেন',
    'Full leaderboard': 'পুরো লিডারবোর্ড',

    # ---- auth
    'Student Login': 'স্টুডেন্ট লগইন',
    'New here?': 'নতুন?',
    'Create an account': 'অ্যাকাউন্ট খুলুন',
    'Create your account': 'আপনার অ্যাকাউন্ট খুলুন',
    'Already have an account?': 'আগে থেকেই অ্যাকাউন্ট আছে?',
    'Only for platform admins.': 'শুধু প্ল্যাটফর্ম অ্যাডমিনদের জন্য।',
    'Full name': 'পুরো নাম',
    'Password': 'পাসওয়ার্ড',
    'Confirm password': 'পাসওয়ার্ড নিশ্চিত করুন',
    'This email is already registered.': 'এই ইমেইল আগেই নিবন্ধিত।',
    'Your account is ready. Welcome!': 'আপনার অ্যাকাউন্ট তৈরি হয়েছে। স্বাগতম!',
    'Your guest quiz attempts were added to your account.': 'আপনার গেস্ট কুইজের চেষ্টাগুলো অ্যাকাউন্টে যোগ হয়েছে।',
    'Wrong email or password, or the account is disabled.': 'ইমেইল বা পাসওয়ার্ড ভুল, অথবা অ্যাকাউন্ট বন্ধ করা আছে।',
    'This is an admin account. Please use the Admin Login page.': 'এটি অ্যাডমিন অ্যাকাউন্ট। অনুগ্রহ করে অ্যাডমিন লগইন পেজ ব্যবহার করুন।',
    'This login is only for admins. Students please use the Student Login page.':
        'এই লগইন শুধু অ্যাডমিনদের জন্য। স্টুডেন্টরা স্টুডেন্ট লগইন পেজ ব্যবহার করুন।',

    # ---- panel: navigation / dashboard
    'Dashboard': 'ড্যাশবোর্ড',
    'Admin Dashboard': 'অ্যাডমিন ড্যাশবোর্ড',
    'Students': 'স্টুডেন্ট',
    'Categories': 'বিভাগ',
    'Questions': 'প্রশ্ন',
    'Results': 'ফলাফল',
    'Excel Upload': 'এক্সেল আপলোড',
    'Total students': 'মোট স্টুডেন্ট',
    'Total categories': 'মোট বিভাগ',
    'Total quizzes': 'মোট কুইজ',
    'Total attempts': 'মোট চেষ্টা',
    'Recent Results': 'সাম্প্রতিক ফলাফল',
    'Leaderboard Overview': 'লিডারবোর্ড সারসংক্ষেপ',
    'Student': 'স্টুডেন্ট',

    # ---- panel: lists
    'Search name, username or email': 'নাম, ইউজারনেম বা ইমেইল খুঁজুন',
    'Search question': 'প্রশ্ন খুঁজুন',
    'Search student': 'স্টুডেন্ট খুঁজুন',
    'Who': 'কে',
    'Guests': 'গেস্ট',
    'Attempts': 'চেষ্টা',
    'Status': 'অবস্থা',
    'Joined': 'যোগ দিয়েছেন',
    'Active': 'সক্রিয়',
    'Inactive': 'নিষ্ক্রিয়',
    'Disabled': 'বন্ধ',
    'Enable': 'চালু করুন',
    'Disable': 'বন্ধ করুন',
    'Activate': 'সক্রিয় করুন',
    'Deactivate': 'নিষ্ক্রিয় করুন',
    'Publish': 'প্রকাশ করুন',
    'Unpublish': 'প্রকাশ বন্ধ করুন',
    'Published': 'প্রকাশিত',
    'Draft': 'খসড়া',
    'Category': 'বিভাগ',
    'Bangla name': 'বাংলা নাম',
    'ID': 'আইডি',
    'Answer': 'উত্তর',
    'Marks (right / wrong)': 'নম্বর (সঠিক / ভুল)',
    'Score': 'স্কোর',
    'Right / Wrong / Skipped': 'সঠিক / ভুল / বাদ',
    'Attempt History': 'চেষ্টার ইতিহাস',
    'This attempt is still in progress.': 'এই চেষ্টাটি এখনো চলছে।',
    'Add category': 'বিভাগ যোগ করুন',
    'Add question': 'প্রশ্ন যোগ করুন',
    'Create quiz': 'কুইজ তৈরি করুন',
    'Edit student': 'স্টুডেন্ট সম্পাদনা',
    'Edit category': 'বিভাগ সম্পাদনা',
    'Edit question': 'প্রশ্ন সম্পাদনা',
    'Edit quiz': 'কুইজ সম্পাদনা',
    'Delete student': 'স্টুডেন্ট মুছুন',
    'Delete category': 'বিভাগ মুছুন',
    'Delete question': 'প্রশ্ন মুছুন',
    'Delete quiz': 'কুইজ মুছুন',
    'Are you sure you want to delete this? This cannot be undone.': 'আপনি কি নিশ্চিত যে এটি মুছতে চান? এটি আর ফেরানো যাবে না।',
    'Yes, delete': 'হ্যাঁ, মুছুন',

    # ---- panel: messages
    'Student updated.': 'স্টুডেন্টের তথ্য হালনাগাদ হয়েছে।',
    'Student account enabled.': 'স্টুডেন্ট অ্যাকাউন্ট চালু করা হয়েছে।',
    'Student account disabled.': 'স্টুডেন্ট অ্যাকাউন্ট বন্ধ করা হয়েছে।',
    'Student deleted.': 'স্টুডেন্ট মুছে ফেলা হয়েছে।',
    'This student cannot be deleted.': 'এই স্টুডেন্টকে মোছা যাবে না।',
    'Category saved.': 'বিভাগ সংরক্ষণ হয়েছে।',
    'Category updated.': 'বিভাগ হালনাগাদ হয়েছে।',
    'Category deleted.': 'বিভাগ মুছে ফেলা হয়েছে।',
    'This category still has questions. Move or delete them first, or make the category inactive.':
        'এই বিভাগে এখনো প্রশ্ন আছে। আগে সেগুলো সরান বা মুছুন, অথবা বিভাগটি নিষ্ক্রিয় করুন।',
    'Question saved.': 'প্রশ্ন সংরক্ষণ হয়েছে।',
    'Question updated.': 'প্রশ্ন হালনাগাদ হয়েছে।',
    'Question deleted.': 'প্রশ্ন মুছে ফেলা হয়েছে।',
    'This question was used in quiz attempts, so it cannot be deleted. Make it inactive instead.':
        'এই প্রশ্ন কুইজের চেষ্টায় ব্যবহৃত হয়েছে, তাই মোছা যাবে না। এর বদলে নিষ্ক্রিয় করুন।',
    'Quiz saved.': 'কুইজ সংরক্ষণ হয়েছে।',
    'Quiz published.': 'কুইজ প্রকাশিত হয়েছে।',
    'Quiz unpublished.': 'কুইজের প্রকাশ বন্ধ করা হয়েছে।',
    'Quiz deleted.': 'কুইজ মুছে ফেলা হয়েছে।',
    'This quiz already has attempts, so it cannot be deleted. Unpublish it instead.':
        'এই কুইজে আগে থেকেই চেষ্টা আছে, তাই মোছা যাবে না। এর বদলে প্রকাশ বন্ধ করুন।',
    'Not enough active questions for this quiz. Add more questions or lower the total.':
        'এই কুইজের জন্য যথেষ্ট সক্রিয় প্রশ্ন নেই। আরও প্রশ্ন যোগ করুন বা মোট সংখ্যা কমান।',

    # ---- panel: Excel
    'Add many questions with Excel': 'এক্সেল দিয়ে একসঙ্গে অনেক প্রশ্ন যোগ করুন',
    'Download the Excel template and fill in your questions.': 'এক্সেল টেমপ্লেট ডাউনলোড করে প্রশ্নগুলো লিখুন।',
    'Download template': 'টেমপ্লেট ডাউনলোড',
    'Upload the file. You will see a preview before anything is saved.': 'ফাইলটি আপলোড করুন। কিছু সংরক্ষণের আগে প্রিভিউ দেখানো হবে।',
    'Check the preview and confirm. Rows with mistakes are skipped and listed so you can fix them.':
        'প্রিভিউ দেখে নিশ্চিত করুন। ভুল থাকা সারি বাদ যাবে এবং তালিকায় দেখানো হবে, যাতে ঠিক করতে পারেন।',
    'Columns: Question, Option A, Option B, Option C, Option D, Correct Answer (A/B/C/D), Category, Explanation (optional), Question (Bangla) (optional), Category (Bangla) (optional).':
        'কলাম: Question, Option A, Option B, Option C, Option D, Correct Answer (A/B/C/D), Category, Explanation (ঐচ্ছিক)।',
    'Excel file (.xlsx)': 'এক্সেল ফাইল (.xlsx)',
    'Upload and preview': 'আপলোড করে প্রিভিউ দেখুন',
    'Preview': 'প্রিভিউ',
    'Rows read': 'পড়া সারি',
    'Ready to import': 'ইমপোর্টের জন্য প্রস্তুত',
    'Rows with errors': 'ভুলসহ সারি',
    'These new categories will be created': 'এই নতুন বিভাগগুলো তৈরি হবে',
    'Error report': 'ভুলের তালিকা',
    'Row': 'সারি',
    'Problem': 'সমস্যা',
    'Questions that will be added': 'যে প্রশ্নগুলো যোগ হবে',
    'first 50 shown': 'প্রথম ৫০টি দেখানো হয়েছে',
    'Import': 'ইমপোর্ট করুন',
    'questions imported.': 'টি প্রশ্ন ইমপোর্ট হয়েছে।',
    'new categories created.': 'টি নতুন বিভাগ তৈরি হয়েছে।',
    'Nothing to import. Please upload the file again.': 'ইমপোর্ট করার কিছু নেই। ফাইলটি আবার আপলোড করুন।',
    'This file could not be read. Please use the downloadable template.': 'ফাইলটি পড়া যায়নি। ডাউনলোড করা টেমপ্লেট ব্যবহার করুন।',

    # ---- form labels
    'Category name': 'বিভাগের নাম',
    'Category name (Bangla)': 'বিভাগের নাম (বাংলা)',
    'Question text': 'প্রশ্ন',
    'Question text (Bangla)': 'প্রশ্ন (বাংলা)',
    'Option A': 'অপশন A', 'Option B': 'অপশন B', 'Option C': 'অপশন C', 'Option D': 'অপশন D',
    'Explanation (optional)': 'ব্যাখ্যা (ঐচ্ছিক)',
    'Quiz name': 'কুইজের নাম',
    'Quiz name (Bangla)': 'কুইজের নাম (বাংলা)',
    'Quiz description': 'কুইজের বিবরণ',
    'Quiz description (Bangla)': 'কুইজের বিবরণ (বাংলা)',
    'Categories (leave empty to use all categories)': 'বিভাগ (ফাঁকা রাখলে সব বিভাগ ধরা হবে)',
    'Seconds per question': 'প্রতি প্রশ্নে সেকেন্ড',
    'Marks for a correct answer': 'সঠিক উত্তরের নম্বর',
    'Marks lost for a wrong answer': 'ভুল উত্তরে কাটা নম্বর',
    'Allow retake': 'পুনরায় দেওয়ার অনুমতি',
    'Published (visible to students)': 'প্রকাশিত (স্টুডেন্টরা দেখতে পাবে)',
    'Account active': 'অ্যাকাউন্ট সক্রিয়',

    # ---- v5: free navigation, about page, team panel
    'Please choose one of the options.':
        'অনুগ্রহ করে একটি অপশন বেছে নিন।',
    'answered':
        'উত্তর দেওয়া হয়েছে',
    'Time left for the whole quiz':
        'পুরো কুইজের বাকি সময়',
    'time left for the whole quiz':
        'পুরো কুইজের বাকি সময়',
    'Jump to a question':
        'যেকোনো প্রশ্নে যান',
    'This is the last question. Check your answers, then submit.':
        'এটি শেষ প্রশ্ন। উত্তরগুলো একবার দেখে নিয়ে জমা দিন।',
    'Answer saved. Tap another option to change it, or go to the next question.':
        'উত্তর সেভ হয়েছে। বদলাতে চাইলে অন্য অপশনে ট্যাপ করুন, নয়তো পরের প্রশ্নে যান।',
    'Tap an option and you move to the next question straight away.':
        'একটি অপশনে ট্যাপ করুন, সঙ্গে সঙ্গে পরের প্রশ্নে চলে যাবেন।',
    'You have {n} unanswered question(s). Submit anyway?':
        'আপনি {n}টি প্রশ্নের উত্তর দেননি। তবুও জমা দেবেন?',
    'Submit your answers now? You cannot change them after this.':
        'এখনই উত্তর জমা দেবেন? জমা দেওয়ার পর আর বদলানো যাবে না।',
    'Submit and see result':
        'জমা দিন ও ফলাফল দেখুন',
    'One question is shown at a time. As soon as you answer, the next question opens.':
        'একবারে একটি প্রশ্ন দেখানো হয়। উত্তর দিলেই সঙ্গে সঙ্গে পরের প্রশ্ন খুলে যায়।',
    'You can go back to any question and change your answer. The time is shared, so the time you save on easy questions is yours for the hard ones.':
        'যেকোনো প্রশ্নে ফিরে গিয়ে উত্তর বদলানো যাবে। সময় সবার জন্য একসাথে, তাই সহজ প্রশ্নে যে সময় বাঁচাবেন সেটা কঠিন প্রশ্নে কাজে লাগবে।',
    'You can submit early. A faster finish helps you on the leaderboard.':
        'চাইলে আগেই জমা দিতে পারবেন। দ্রুত শেষ করলে লিডারবোর্ডে সুবিধা পাবেন।',
    'Every question gets 30 seconds on average. Answer fast, move on, and spend the time you saved on the hard ones.':
        'প্রতি প্রশ্নে গড়ে ৩০ সেকেন্ড। দ্রুত উত্তর দিন, এগিয়ে যান, আর বাঁচানো সময় কঠিন প্রশ্নে কাজে লাগান।',
    'About Us':
        'আমাদের সম্পর্কে',
    'Learn about Gyanchorcha and meet the team that builds this platform.':
        'জ্ঞানচর্চা সম্পর্কে জানুন এবং যে টিম এই প্ল্যাটফর্মটি তৈরি করছে তাদের সাথে পরিচিত হন।',
    'Gyanchorcha is built for students in Bangladesh. Learn in Bangla, test yourself in a few minutes, and grow a little every day.':
        'জ্ঞানচর্চা বাংলাদেশের শিক্ষার্থীদের জন্য তৈরি। বাংলায় শিখুন, কয়েক মিনিটে নিজেকে যাচাই করুন, আর প্রতিদিন একটু একটু করে এগিয়ে যান।',
    'Our team':
        'আমাদের টিম',
    'Team members will appear here soon.':
        'টিম সদস্যদের পরিচিতি শিগগিরই এখানে দেখা যাবে।',
    'Team':
        'টিম',
    'Add team member':
        'টিম সদস্য যোগ করুন',
    'Edit team member':
        'টিম সদস্য সম্পাদনা',
    'Delete team member':
        'টিম সদস্য মুছুন',
    'Team member saved.':
        'টিম সদস্য সংরক্ষিত হয়েছে।',
    'Team member updated.':
        'টিম সদস্যের তথ্য হালনাগাদ হয়েছে।',
    'Team member deleted.':
        'টিম সদস্য মুছে ফেলা হয়েছে।',
    'This team member cannot be deleted.':
        'এই টিম সদস্যকে মোছা যাচ্ছে না।',
    'These people are shown on the public About Us page.':
        'এই সদস্যরা সবার জন্য খোলা "আমাদের সম্পর্কে" পেজে দেখানো হবে।',
    'Role':
        'ভূমিকা',
    'Order':
        'ক্রম',
    'Shown':
        'দেখানো হচ্ছে',
    'Hidden':
        'লুকানো',
    'Hide':
        'লুকান',
    'Show':
        'দেখান',
    'Name (Bangla)':
        'নাম (বাংলা)',
    'Role (Bangla)':
        'ভূমিকা (বাংলা)',
    'Work / about':
        'কাজ / পরিচিতি',
    'Work / about (Bangla)':
        'কাজ / পরিচিতি (বাংলা)',
    'Photo link (optional)':
        'ছবির লিংক (ঐচ্ছিক)',
    'Order (small number comes first)':
        'ক্রম (ছোট সংখ্যা আগে আসবে)',
    'Show on About page':
        'আমাদের সম্পর্কে পেজে দেখান',
    'Add student': 'স্টুডেন্ট যোগ করুন',
    'Student added.': 'স্টুডেন্ট যোগ করা হয়েছে।',
    'About page': 'আমাদের সম্পর্কে পেজ',
    'About page text': 'আমাদের সম্পর্কে পেজের লেখা',
    'About page saved.': 'আমাদের সম্পর্কে পেজ সংরক্ষণ করা হয়েছে।',
    'Heading': 'শিরোনাম',
    'Heading (Bangla)': 'শিরোনাম (বাংলা)',
    'Short intro': 'সংক্ষিপ্ত পরিচিতি',
    'Short intro (Bangla)': 'সংক্ষিপ্ত পরিচিতি (বাংলা)',
    'Our story / mission': 'আমাদের গল্প / লক্ষ্য',
    'Our story / mission (Bangla)': 'আমাদের গল্প / লক্ষ্য (বাংলা)',
    'Contact email (optional)': 'যোগাযোগের ইমেইল (ঐচ্ছিক)',
    'Contact': 'যোগাযোগ',
}
